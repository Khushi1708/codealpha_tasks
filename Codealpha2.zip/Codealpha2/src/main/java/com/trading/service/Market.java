package com.trading.service;

import com.trading.model.Stock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Market {
    private Map<String, Stock> availableStocks;
    private Random random;

    public Market() {
        this.availableStocks = new HashMap<>();
        this.random = new Random();
        initializeMarket();
    }

    private void initializeMarket() {
        addStock(new Stock("AAPL", "Apple Inc.", 150.00));
        addStock(new Stock("GOOGL", "Alphabet Inc.", 2800.00));
        addStock(new Stock("MSFT", "Microsoft Corp.", 300.00));
        addStock(new Stock("AMZN", "Amazon.com Inc.", 3400.00));
        addStock(new Stock("TSLA", "Tesla Inc.", 700.00));
    }

    private void addStock(Stock stock) {
        availableStocks.put(stock.getSymbol(), stock);
    }

    public Stock getStock(String symbol) {
        return availableStocks.get(symbol.toUpperCase());
    }

    public List<Stock> getAllStocks() {
        return new ArrayList<>(availableStocks.values());
    }

    public void simulateMarketFluctuation() {
        for (Stock stock : availableStocks.values()) {
            // Fluctuate price by -5% to +5%
            double fluctuation = (random.nextDouble() * 0.10) - 0.05;
            double currentPrice = stock.getCurrentPrice();
            double newPrice = currentPrice * (1 + fluctuation);
            
            // Ensure price doesn't drop below $0.01
            if (newPrice < 0.01) {
                newPrice = 0.01;
            }
            
            stock.updatePrice(newPrice);
        }
    }

    public void displayMarket() {
        System.out.println("\n--- Current Market Data ---");
        System.out.printf("%-6s | %-20s | %s%n", "Symbol", "Company Name", "Price");
        System.out.println("--------------------------------------------------");
        for (Stock stock : availableStocks.values()) {
            System.out.println(stock.toString());
        }
        System.out.println("--------------------------------------------------\n");
    }
}
