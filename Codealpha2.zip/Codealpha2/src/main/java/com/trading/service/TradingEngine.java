package com.trading.service;

import com.trading.model.Stock;
import com.trading.model.User;

public class TradingEngine {

    public boolean buyStock(User user, Stock stock, int quantity) {
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than 0.");
            return false;
        }

        double totalCost = stock.getCurrentPrice() * quantity;
        
        if (user.getCashBalance() >= totalCost) {
            try {
                user.deductFunds(totalCost);
                user.getPortfolio().addStock(stock, quantity);
                System.out.printf("Successfully bought %d shares of %s at $%.2f each.%n", quantity, stock.getSymbol(), stock.getCurrentPrice());
                return true;
            } catch (Exception e) {
                System.out.println("Error completing purchase: " + e.getMessage());
                return false;
            }
        } else {
            System.out.println("Insufficient funds. You need $" + String.format("%.2f", totalCost) + " but have $" + String.format("%.2f", user.getCashBalance()));
            return false;
        }
    }

    public boolean sellStock(User user, Stock stock, int quantity) {
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than 0.");
            return false;
        }

        int currentQuantity = user.getPortfolio().getQuantity(stock);
        
        if (currentQuantity >= quantity) {
            try {
                double totalRevenue = stock.getCurrentPrice() * quantity;
                user.getPortfolio().removeStock(stock, quantity);
                user.addFunds(totalRevenue);
                System.out.printf("Successfully sold %d shares of %s at $%.2f each.%n", quantity, stock.getSymbol(), stock.getCurrentPrice());
                return true;
            } catch (Exception e) {
                System.out.println("Error completing sale: " + e.getMessage());
                return false;
            }
        } else {
            System.out.println("Insufficient shares. You want to sell " + quantity + " but only have " + currentQuantity);
            return false;
        }
    }
}
