package com.trading.model;

import java.util.HashMap;
import java.util.Map;

public class Portfolio {
    private Map<Stock, Integer> holdings;

    public Portfolio() {
        this.holdings = new HashMap<>();
    }

    public void addStock(Stock stock, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        holdings.put(stock, holdings.getOrDefault(stock, 0) + quantity);
    }

    public void removeStock(Stock stock, int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        int currentQuantity = holdings.getOrDefault(stock, 0);
        if (currentQuantity < quantity) {
            throw new IllegalArgumentException("Insufficient stock quantity to remove");
        }
        
        if (currentQuantity == quantity) {
            holdings.remove(stock);
        } else {
            holdings.put(stock, currentQuantity - quantity);
        }
    }

    public int getQuantity(Stock stock) {
        return holdings.getOrDefault(stock, 0);
    }

    public double getTotalValue() {
        double total = 0.0;
        for (Map.Entry<Stock, Integer> entry : holdings.entrySet()) {
            total += entry.getKey().getCurrentPrice() * entry.getValue();
        }
        return total;
    }

    public Map<Stock, Integer> getHoldings() {
        return holdings;
    }
}
