package com.trading.model;

public class User {
    private String name;
    private double cashBalance;
    private Portfolio portfolio;

    public User(String name, double initialBalance) {
        this.name = name;
        this.cashBalance = initialBalance;
        this.portfolio = new Portfolio();
    }

    public String getName() { return name; }
    public double getCashBalance() { return cashBalance; }
    public Portfolio getPortfolio() { return portfolio; }

    public void addFunds(double amount) {
        if (amount > 0) {
            this.cashBalance += amount;
        }
    }

    public void deductFunds(double amount) {
        if (amount > 0 && this.cashBalance >= amount) {
            this.cashBalance -= amount;
        } else {
            throw new IllegalArgumentException("Insufficient funds or invalid amount");
        }
    }

    public double getTotalNetWorth() {
        return cashBalance + portfolio.getTotalValue();
    }
}
