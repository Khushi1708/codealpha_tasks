package com.trading.ui;

import com.trading.model.Stock;
import com.trading.model.User;
import com.trading.service.Market;
import com.trading.service.TradingEngine;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;

public class MainDashboard extends JFrame {
    private Market market;
    private TradingEngine engine;
    private User user;

    private JLabel balanceLabel;
    private JLabel netWorthLabel;
    
    private JTable marketTable;
    private DefaultTableModel marketTableModel;
    
    private JTable portfolioTable;
    private DefaultTableModel portfolioTableModel;

    private JTextField symbolField;
    private JTextField quantityField;

    public MainDashboard(Market market, TradingEngine engine, User user) {
        this.market = market;
        this.engine = engine;
        this.user = user;

        setTitle("Stock Trading Dashboard - " + user.getName());
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
        refreshData();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Top Panel: User Info
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 10));
        balanceLabel = new JLabel("Cash Balance: $0.00");
        netWorthLabel = new JLabel("Net Worth: $0.00");
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        netWorthLabel.setFont(new Font("Arial", Font.BOLD, 16));
        topPanel.add(balanceLabel);
        topPanel.add(netWorthLabel);
        add(topPanel, BorderLayout.NORTH);

        // Center Panel: Tables
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 10, 0));

        // Market Table
        marketTableModel = new DefaultTableModel(new String[]{"Symbol", "Company", "Price"}, 0);
        marketTable = new JTable(marketTableModel);
        JScrollPane marketScroll = new JScrollPane(marketTable);
        marketScroll.setBorder(BorderFactory.createTitledBorder("Available Market"));
        centerPanel.add(marketScroll);

        // Portfolio Table
        portfolioTableModel = new DefaultTableModel(new String[]{"Symbol", "Quantity", "Price", "Total Value"}, 0);
        portfolioTable = new JTable(portfolioTableModel);
        JScrollPane portfolioScroll = new JScrollPane(portfolioTable);
        portfolioScroll.setBorder(BorderFactory.createTitledBorder("Your Portfolio"));
        centerPanel.add(portfolioScroll);

        add(centerPanel, BorderLayout.CENTER);

        // Bottom Panel: Controls
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        bottomPanel.add(new JLabel("Symbol:"));
        symbolField = new JTextField(6);
        bottomPanel.add(symbolField);

        bottomPanel.add(new JLabel("Quantity:"));
        quantityField = new JTextField(5);
        bottomPanel.add(quantityField);

        JButton buyBtn = new JButton("Buy");
        buyBtn.addActionListener(e -> handleBuy());
        bottomPanel.add(buyBtn);

        JButton sellBtn = new JButton("Sell");
        sellBtn.addActionListener(e -> handleSell());
        bottomPanel.add(sellBtn);

        JButton advanceTimeBtn = new JButton("Advance Time");
        advanceTimeBtn.addActionListener(e -> handleAdvanceTime());
        bottomPanel.add(advanceTimeBtn);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void refreshData() {
        // Update Labels
        balanceLabel.setText(String.format("Cash Balance: $%.2f", user.getCashBalance()));
        netWorthLabel.setText(String.format("Net Worth: $%.2f", user.getTotalNetWorth()));

        // Update Market Table
        marketTableModel.setRowCount(0);
        for (Stock stock : market.getAllStocks()) {
            marketTableModel.addRow(new Object[]{
                    stock.getSymbol(),
                    stock.getName(),
                    String.format("$%.2f", stock.getCurrentPrice())
            });
        }

        // Update Portfolio Table
        portfolioTableModel.setRowCount(0);
        Map<Stock, Integer> holdings = user.getPortfolio().getHoldings();
        for (Map.Entry<Stock, Integer> entry : holdings.entrySet()) {
            Stock stock = entry.getKey();
            int qty = entry.getValue();
            double value = stock.getCurrentPrice() * qty;
            portfolioTableModel.addRow(new Object[]{
                    stock.getSymbol(),
                    qty,
                    String.format("$%.2f", stock.getCurrentPrice()),
                    String.format("$%.2f", value)
            });
        }
    }

    private void handleBuy() {
        String symbol = symbolField.getText().toUpperCase().trim();
        Stock stock = market.getStock(symbol);
        if (stock == null) {
            JOptionPane.showMessageDialog(this, "Stock symbol not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityField.getText().trim());
            boolean success = engine.buyStock(user, stock, quantity);
            if (success) {
                JOptionPane.showMessageDialog(this, "Successfully bought " + quantity + " shares of " + symbol);
                refreshData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to buy stock. Check cash balance.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid quantity. Enter a whole number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleSell() {
        String symbol = symbolField.getText().toUpperCase().trim();
        Stock stock = market.getStock(symbol);
        if (stock == null) {
            JOptionPane.showMessageDialog(this, "Stock symbol not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityField.getText().trim());
            boolean success = engine.sellStock(user, stock, quantity);
            if (success) {
                JOptionPane.showMessageDialog(this, "Successfully sold " + quantity + " shares of " + symbol);
                refreshData();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to sell stock. Check share quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid quantity. Enter a whole number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleAdvanceTime() {
        market.simulateMarketFluctuation();
        refreshData();
        JOptionPane.showMessageDialog(this, "Time advanced! Market prices have fluctuated.", "Market Update", JOptionPane.INFORMATION_MESSAGE);
    }
}
