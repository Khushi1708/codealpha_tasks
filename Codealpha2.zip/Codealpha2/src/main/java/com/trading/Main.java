package com.trading;

import com.trading.model.User;
import com.trading.service.Market;
import com.trading.service.TradingEngine;
import com.trading.ui.MainDashboard;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Run GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            Market market = new Market();
            TradingEngine tradingEngine = new TradingEngine();
            User user = new User("Trader", 10000.0); // Start with $10k
            
            MainDashboard dashboard = new MainDashboard(market, tradingEngine, user);
            dashboard.setVisible(true);
        });
    }
}
