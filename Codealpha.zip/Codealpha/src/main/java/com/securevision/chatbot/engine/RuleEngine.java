package com.securevision.chatbot.engine;

import java.util.*;
import java.util.regex.*;

/**
 * RuleEngine - Regex-based pattern matching for common intents.
 * 
 * The rule engine handles:
 * - Greetings and farewells
 * - Special commands (help, topics, reset)
 * - Time and date queries
 * - Simple conversational patterns
 * 
 * Rules are checked BEFORE the ML similarity engine, providing
 * instant responses for common, well-defined patterns.
 */
public class RuleEngine {

    /**
     * Result of a rule match containing the response and matched rule name.
     */
    public static class RuleResult {
        public final String response;
        public final String ruleName;
        public final double confidence;

        public RuleResult(String response, String ruleName, double confidence) {
            this.response = response;
            this.ruleName = ruleName;
            this.confidence = confidence;
        }
    }

    private static final Random RANDOM = new Random();
    private final List<Rule> rules;

    public RuleEngine() {
        this.rules = new ArrayList<>();
        initializeRules();
    }

    /**
     * Tries to match user input against all rules.
     * Returns the first matching rule result, or null if no match.
     *
     * @param cleanedInput Lowercased, trimmed user input
     * @return RuleResult or null
     */
    public RuleResult match(String cleanedInput) {
        if (cleanedInput == null || cleanedInput.trim().isEmpty()) {
            return new RuleResult(
                "It looks like you didn't type anything. How can I help you? 😊",
                "empty_input", 1.0
            );
        }

        for (Rule rule : rules) {
            if (rule.matches(cleanedInput)) {
                return new RuleResult(
                    rule.getRandomResponse(),
                    rule.name,
                    rule.confidence
                );
            }
        }

        return null;
    }

    // --- Rule Definitions ---

    private void initializeRules() {
        // Greetings (highest priority)
        addRule("greeting",
            "^(hi|hello|hey|howdy|greetings|yo|sup|hiya|hola|heya|good\\s*(morning|afternoon|evening|day))\\b.*$",
            0.95,
            "Hello! 👋 Welcome! I'm your AI assistant. How can I help you today?",
            "Hey there! 😊 Great to see you! What can I do for you?",
            "Hi! 🌟 I'm here and ready to help. What's on your mind?",
            "Greetings! 👋 I'm your AI chatbot assistant. Ask me anything!",
            "Hello! 😃 Nice to meet you! Feel free to ask me any questions."
        );

        // How are you
        addRule("how_are_you",
            ".*(how\\s+are\\s+you|how\\s+do\\s+you\\s+do|how\\s+you\\s+doing|how's\\s+it\\s+going|what'?s\\s+up).*",
            0.90,
            "I'm doing great, thank you for asking! 😊 I'm always ready to chat. What can I help you with?",
            "I'm functioning perfectly! 🚀 As an AI, every moment is a good moment. How about you?",
            "Wonderful, thanks! 💫 I'm here and ready to assist. What would you like to know?",
            "I'm excellent! ⚡ Running at full capacity. What questions do you have for me?"
        );

        // Farewell
        addRule("farewell",
            "^(bye|goodbye|see\\s+you|farewell|take\\s+care|later|good\\s*night|gotta\\s+go|ciao|peace|quit|exit)\\b.*$",
            0.95,
            "Goodbye! 👋 It was great chatting with you. Come back anytime!",
            "See you later! 😊 Have a wonderful day!",
            "Farewell! 🌟 Don't hesitate to come back if you need anything!",
            "Take care! 👋 I'll be here whenever you need me!"
        );

        // Thanks
        addRule("thanks",
            ".*(thank\\s*(you|u|s)|thanks|thx|appreciate\\s+it|grateful).*",
            0.90,
            "You're welcome! 😊 Happy to help! Is there anything else you'd like to know?",
            "My pleasure! 🌟 Don't hesitate to ask if you have more questions!",
            "Glad I could help! 💫 Feel free to ask anything else!",
            "Anytime! 😃 I'm here to assist you whenever you need."
        );

        // Help command
        addRule("help",
            "^(help|commands|what\\s+can\\s+you\\s+do|menu|options)\\b.*$",
            0.98,
            "Here's what I can help you with! 📋\n\n" +
            "🤖 **AI & Technology** - Ask about AI, machine learning, NLP, and more\n" +
            "💻 **Programming** - Java, OOP, APIs, databases, and coding concepts\n" +
            "🔧 **Technical Support** - Account issues, passwords, and troubleshooting\n" +
            "📚 **General Knowledge** - Various topics and fun conversations\n" +
            "💬 **Conversation** - Jokes, quotes, and friendly chat\n\n" +
            "Try asking things like:\n" +
            "• \"What is artificial intelligence?\"\n" +
            "• \"Explain machine learning\"\n" +
            "• \"Tell me a joke\"\n" +
            "• \"What is Java?\"\n\n" +
            "Type **topics** to see all available categories!"
        );

        // Topics command
        addRule("topics",
            "^(topics|categories|subjects|list\\s+topics)\\b.*$",
            0.98,
            "Here are the topics I can discuss! 📚\n\n" +
            "🤖 **Artificial Intelligence** - AI concepts, history, and applications\n" +
            "🧠 **Machine Learning** - ML algorithms, types, and use cases\n" +
            "🗣️ **Natural Language Processing** - NLP techniques and applications\n" +
            "💻 **Programming** - Java, OOP, APIs, and software concepts\n" +
            "🌐 **Web Development** - Frontend, backend, and web technologies\n" +
            "🔒 **Cybersecurity** - Security concepts and best practices\n" +
            "☁️ **Cloud Computing** - Cloud services and architecture\n" +
            "📊 **Data Science** - Analytics, visualization, and big data\n" +
            "🔧 **Support** - Account help and troubleshooting\n" +
            "💬 **Fun & Chat** - Jokes, quotes, and general conversation\n\n" +
            "Just ask me about any of these topics! 😊"
        );

        // Bot identity
        addRule("bot_identity",
            ".*(what\\s+is\\s+your\\s+name|who\\s+are\\s+you|what\\s+are\\s+you|are\\s+you\\s+a\\s+(bot|robot|ai|human)).*",
            0.92,
            "I'm SecureVision AI 🤖 — a chatbot built with Java and Natural Language Processing! I use TF-IDF vectorization and cosine similarity to understand your questions. How can I help you today?",
            "Great question! I'm SecureVision AI, your intelligent chatbot assistant. 🌟 I was built using Java with custom NLP techniques. Feel free to ask me anything!",
            "I'm an AI chatbot called SecureVision AI! 🤖 I use NLP and machine learning techniques to understand and respond to your questions. Try me!"
        );

        // Creator/maker
        addRule("creator",
            ".*(who\\s+(made|created|built|designed|developed)\\s+you|your\\s+(creator|developer|maker)).*",
            0.92,
            "I was created as part of the SecureVision project! 🛠️ Built with Java, featuring custom NLP processing, TF-IDF vectorization, and a beautiful web interface.",
            "I'm a product of the SecureVision team! 🌟 Designed and built using pure Java with custom natural language processing capabilities."
        );

        // Capabilities
        addRule("capabilities",
            ".*(what\\s+can\\s+you|your\\s+capabilities|what\\s+do\\s+you\\s+know|what\\s+topics|what\\s+are\\s+you\\s+capable).*",
            0.88,
            "I can help you with lots of things! 🚀\n\n" +
            "• Answer questions about AI, ML, and technology\n" +
            "• Explain programming concepts\n" +
            "• Discuss NLP and data science topics\n" +
            "• Share jokes and fun facts\n" +
            "• Provide technical support guidance\n\n" +
            "Type **help** or **topics** to see more details!"
        );

        // Compliments
        addRule("compliment",
            ".*(you\\s+are\\s+(smart|awesome|great|cool|amazing|wonderful|brilliant|helpful|good)|nice\\s+bot|love\\s+you|good\\s+job|well\\s+done).*",
            0.85,
            "Aww, thank you so much! 😊💕 That means a lot! I'll keep doing my best to help you!",
            "You're too kind! 🌟 Thank you! I'm here to make your day better!",
            "That's so sweet of you! 😃 I'm glad you're enjoying our chat!"
        );

        // Insults (handle gracefully)
        addRule("insult",
            ".*(you\\s+are\\s+(stupid|dumb|bad|useless|terrible|worst|ugly|idiot)|hate\\s+you|you\\s+suck).*",
            0.85,
            "I'm sorry you feel that way! 😔 I'm always learning and trying to improve. Could you tell me what I can do better?",
            "I understand your frustration. 💪 I'm not perfect, but I'm trying my best! How can I help you today?",
            "That's okay! I'm always working on improving. 🌱 Let me try to help you with something — ask me a question!"
        );
    }

    private void addRule(String name, String pattern, double confidence, String... responses) {
        rules.add(new Rule(name, pattern, confidence, responses));
    }

    // --- Inner Rule Class ---

    private static class Rule {
        final String name;
        final Pattern pattern;
        final double confidence;
        final String[] responses;

        Rule(String name, String regex, double confidence, String... responses) {
            this.name = name;
            this.pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            this.confidence = confidence;
            this.responses = responses;
        }

        boolean matches(String input) {
            return pattern.matcher(input).matches();
        }

        String getRandomResponse() {
            return responses[RANDOM.nextInt(responses.length)];
        }
    }
}
