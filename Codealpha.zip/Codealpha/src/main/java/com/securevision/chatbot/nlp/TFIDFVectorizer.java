package com.securevision.chatbot.nlp;

import java.util.*;

/**
 * TFIDFVectorizer - Computes Term Frequency-Inverse Document Frequency scores.
 * 
 * TF-IDF is a statistical measure that evaluates how important a word is to
 * a document in a collection. It combines:
 * - TF (Term Frequency): How often a word appears in a document
 * - IDF (Inverse Document Frequency): How rare a word is across all documents
 * 
 * This is the core of the ML-style matching — it converts text into numerical
 * vectors that can be compared using cosine similarity.
 */
public class TFIDFVectorizer {

    private List<List<String>> corpus;          // All documents (stemmed token lists)
    private Map<String, Double> idfScores;      // IDF score for each term
    private List<String> vocabulary;            // Ordered list of all unique terms
    private Map<String, Integer> vocabIndex;    // Term -> index mapping

    public TFIDFVectorizer() {
        this.corpus = new ArrayList<>();
        this.idfScores = new HashMap<>();
        this.vocabulary = new ArrayList<>();
        this.vocabIndex = new HashMap<>();
    }

    /**
     * Trains the vectorizer on a corpus of documents.
     * Call this once with all FAQ training phrases.
     *
     * @param documents List of documents, where each document is a list of stemmed tokens
     */
    public void fit(List<List<String>> documents) {
        this.corpus = documents;
        buildVocabulary();
        computeIDF();
    }

    /**
     * Transforms a single document (token list) into a TF-IDF vector.
     *
     * @param tokens Stemmed token list
     * @return TF-IDF vector (sparse, as a double array)
     */
    public double[] transform(List<String> tokens) {
        double[] vector = new double[vocabulary.size()];

        // Compute term frequency
        Map<String, Integer> tf = new HashMap<>();
        for (String token : tokens) {
            tf.put(token, tf.getOrDefault(token, 0) + 1);
        }

        // Compute TF-IDF for each term
        for (Map.Entry<String, Integer> entry : tf.entrySet()) {
            String term = entry.getKey();
            if (vocabIndex.containsKey(term)) {
                int idx = vocabIndex.get(term);
                double termFreq = (double) entry.getValue() / tokens.size();
                double idf = idfScores.getOrDefault(term, 0.0);
                vector[idx] = termFreq * idf;
            }
        }

        return vector;
    }

    /**
     * Transforms all documents in the fitted corpus into TF-IDF vectors.
     *
     * @return List of TF-IDF vectors
     */
    public List<double[]> transformCorpus() {
        List<double[]> vectors = new ArrayList<>();
        for (List<String> doc : corpus) {
            vectors.add(transform(doc));
        }
        return vectors;
    }

    /**
     * Computes the cosine similarity between two TF-IDF vectors.
     *
     * @param v1 First vector
     * @param v2 Second vector
     * @return Cosine similarity score between 0.0 and 1.0
     */
    public static double cosineSimilarity(double[] v1, double[] v2) {
        if (v1.length != v2.length) return 0.0;

        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;

        for (int i = 0; i < v1.length; i++) {
            dotProduct += v1[i] * v2[i];
            normA += v1[i] * v1[i];
            normB += v2[i] * v2[i];
        }

        double denominator = Math.sqrt(normA) * Math.sqrt(normB);
        if (denominator == 0.0) return 0.0;

        return dotProduct / denominator;
    }

    /**
     * Returns the vocabulary size.
     */
    public int getVocabularySize() {
        return vocabulary.size();
    }

    /**
     * Returns the vocabulary terms.
     */
    public List<String> getVocabulary() {
        return Collections.unmodifiableList(vocabulary);
    }

    // --- Private Methods ---

    private void buildVocabulary() {
        Set<String> terms = new LinkedHashSet<>();
        for (List<String> doc : corpus) {
            terms.addAll(doc);
        }
        vocabulary = new ArrayList<>(terms);
        vocabIndex = new HashMap<>();
        for (int i = 0; i < vocabulary.size(); i++) {
            vocabIndex.put(vocabulary.get(i), i);
        }
    }

    private void computeIDF() {
        int n = corpus.size();
        for (String term : vocabulary) {
            int docCount = 0;
            for (List<String> doc : corpus) {
                if (doc.contains(term)) {
                    docCount++;
                }
            }
            // Smoothed IDF: log((N + 1) / (df + 1)) + 1
            double idf = Math.log((double)(n + 1) / (docCount + 1)) + 1.0;
            idfScores.put(term, idf);
        }
    }
}
