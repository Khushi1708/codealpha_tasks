package com.securevision.chatbot.nlp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * StopWordRemover - Filters common English stop words from token lists.
 * 
 * Stop words are high-frequency words that carry little semantic meaning
 * (e.g., "the", "is", "at"). Removing them improves NLP accuracy by
 * focusing on content-bearing words.
 */
public class StopWordRemover {

    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
        // Articles
        "a", "an", "the",
        // Pronouns
        "i", "me", "my", "myself", "we", "our", "ours", "ourselves",
        "you", "your", "yours", "yourself", "yourselves",
        "he", "him", "his", "himself", "she", "her", "hers", "herself",
        "it", "its", "itself", "they", "them", "their", "theirs", "themselves",
        // Prepositions
        "in", "on", "at", "to", "for", "with", "from", "by", "about",
        "into", "through", "during", "before", "after", "above", "below",
        "between", "under", "over", "up", "down", "out", "off", "of",
        // Conjunctions
        "and", "but", "or", "nor", "so", "yet", "both", "either", "neither",
        // Be verbs
        "is", "am", "are", "was", "were", "be", "been", "being",
        // Have verbs
        "has", "have", "had", "having",
        // Do verbs
        "do", "does", "did", "doing",
        // Modal verbs
        "will", "would", "shall", "should", "may", "might", "must",
        "can", "could",
        // Other common words
        "that", "which", "who", "whom", "this", "these", "those",
        "each", "every", "all", "any", "few", "more", "most", "some",
        "such", "no", "not", "only", "own", "same", "than", "too",
        "very", "just", "because", "as", "until", "while", "if",
        "then", "once", "here", "there", "when", "where", "why", "how",
        "what", "again", "further", "also", "other", "another",
        "much", "many", "even", "still", "already", "enough",
        // Additional high-frequency words
        "get", "got", "go", "going", "gone", "come", "came",
        "make", "made", "take", "took", "give", "gave",
        "say", "said", "tell", "told", "ask", "asked",
        "think", "thought", "know", "knew", "see", "saw",
        "want", "wanted", "need", "needed", "like", "use", "used",
        "try", "tried", "find", "found", "put", "set",
        "thing", "things", "way", "ways", "well", "back",
        "really", "right", "yes", "yeah", "ok", "okay",
        "please", "thanks", "thank"
    ));

    /**
     * Removes stop words from a list of tokens.
     *
     * @param tokens List of word tokens
     * @return Filtered list without stop words
     */
    public List<String> removeStopWords(List<String> tokens) {
        List<String> filtered = new ArrayList<>();
        for (String token : tokens) {
            if (!STOP_WORDS.contains(token.toLowerCase())) {
                filtered.add(token);
            }
        }
        return filtered;
    }

    /**
     * Checks if a word is a stop word.
     *
     * @param word The word to check
     * @return true if the word is a stop word
     */
    public boolean isStopWord(String word) {
        return STOP_WORDS.contains(word.toLowerCase());
    }

    /**
     * Returns the number of stop words in the dictionary.
     */
    public int getStopWordCount() {
        return STOP_WORDS.size();
    }
}
