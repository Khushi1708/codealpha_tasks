package com.securevision.chatbot.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ChatMessage - Represents a single chat message in the conversation.
 * 
 * Each message has a sender (user or bot), content text, timestamp,
 * and optional metadata like confidence score and matched intent.
 */
public class ChatMessage {

    public enum Sender {
        USER, BOT
    }

    private final Sender sender;
    private final String content;
    private final String timestamp;
    private final double confidence;
    private final String matchedIntent;

    private static final DateTimeFormatter FORMATTER = 
        DateTimeFormatter.ofPattern("HH:mm");

    public ChatMessage(Sender sender, String content) {
        this(sender, content, 1.0, null);
    }

    public ChatMessage(Sender sender, String content, double confidence, String matchedIntent) {
        this.sender = sender;
        this.content = content;
        this.timestamp = LocalDateTime.now().format(FORMATTER);
        this.confidence = confidence;
        this.matchedIntent = matchedIntent;
    }

    public Sender getSender() { return sender; }
    public String getContent() { return content; }
    public String getTimestamp() { return timestamp; }
    public double getConfidence() { return confidence; }
    public String getMatchedIntent() { return matchedIntent; }

    /**
     * Converts this message to a JSON string for API responses.
     */
    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"sender\":\"").append(sender.name().toLowerCase()).append("\",");
        sb.append("\"content\":\"").append(escapeJson(content)).append("\",");
        sb.append("\"timestamp\":\"").append(timestamp).append("\",");
        sb.append("\"confidence\":").append(String.format("%.2f", confidence));
        if (matchedIntent != null) {
            sb.append(",\"intent\":\"").append(escapeJson(matchedIntent)).append("\"");
        }
        sb.append("}");
        return sb.toString();
    }

    private String escapeJson(String text) {
        if (text == null) return "";
        return text
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t");
    }

    @Override
    public String toString() {
        return String.format("[%s] %s: %s", timestamp, sender, content);
    }
}
