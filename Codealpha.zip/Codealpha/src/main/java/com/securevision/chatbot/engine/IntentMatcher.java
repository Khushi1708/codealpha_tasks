package com.securevision.chatbot.engine;

import com.securevision.chatbot.model.ChatMessage;
import com.securevision.chatbot.model.KnowledgeBase;
import com.securevision.chatbot.nlp.NLPProcessor;

import java.util.Random;

/**
 * IntentMatcher - Hybrid intent matching combining rules and ML similarity.
 * 
 * Processing order:
 * 1. Rule Engine (regex patterns) - fast, high-confidence matches
 * 2. Similarity Engine (TF-IDF + cosine) - ML-style fuzzy matching
 * 3. Fallback - generic "I don't understand" response
 * 
 * This provides the best of both worlds: instant rule-based responses for
 * common patterns, and intelligent fuzzy matching for complex questions.
 */
public class IntentMatcher {

    private final NLPProcessor nlpProcessor;
    private final RuleEngine ruleEngine;
    private final SimilarityEngine similarityEngine;
    private static final Random RANDOM = new Random();

    private static final String[] FALLBACK_RESPONSES = {
        "I'm not quite sure I understand that. 🤔 Could you rephrase your question? You can also type **help** to see what I can assist with!",
        "Hmm, that's a tricky one! 😅 I don't have a great answer for that. Try asking me about AI, programming, or technology topics!",
        "I'm still learning! 📚 I couldn't find a match for that question. Try rephrasing, or type **topics** to see what I know about!",
        "That's outside my current knowledge. 🌱 But I'm constantly improving! Try asking about artificial intelligence, Java, or machine learning.",
        "I appreciate your question, but I'm not confident in my answer. 🤖 Type **help** to see the topics I can help with!"
    };

    public IntentMatcher() {
        this.nlpProcessor = new NLPProcessor();
        this.ruleEngine = new RuleEngine();
        this.similarityEngine = new SimilarityEngine(nlpProcessor);
    }

    /**
     * Trains the intent matcher on the knowledge base.
     */
    public void train(KnowledgeBase knowledgeBase) {
        similarityEngine.train(knowledgeBase);
    }

    /**
     * Processes user input and returns the best bot response.
     *
     * @param userInput Raw user input text
     * @return ChatMessage with the bot's response
     */
    public ChatMessage processInput(String userInput) {
        if (userInput == null || userInput.trim().isEmpty()) {
            return new ChatMessage(
                ChatMessage.Sender.BOT,
                "It looks like you didn't type anything. How can I help you? 😊",
                1.0, "empty_input"
            );
        }

        String cleanedInput = nlpProcessor.clean(userInput);

        // Step 1: Try rule engine first (fast, high confidence)
        RuleEngine.RuleResult ruleResult = ruleEngine.match(cleanedInput);
        if (ruleResult != null) {
            System.out.println("[IntentMatcher] Rule match: " + ruleResult.ruleName 
                + " (confidence: " + ruleResult.confidence + ")");
            return new ChatMessage(
                ChatMessage.Sender.BOT,
                ruleResult.response,
                ruleResult.confidence,
                ruleResult.ruleName
            );
        }

        // Step 2: Try ML similarity engine (fuzzy matching)
        SimilarityEngine.MatchResult mlResult = similarityEngine.findBestMatch(userInput);
        if (mlResult != null) {
            System.out.println("[IntentMatcher] ML match: " + mlResult.intent.getTag() 
                + " (confidence: " + String.format("%.4f", mlResult.confidence) + ")");
            return new ChatMessage(
                ChatMessage.Sender.BOT,
                mlResult.intent.getRandomResponse(),
                mlResult.confidence,
                mlResult.intent.getTag()
            );
        }

        // Step 3: Fallback
        System.out.println("[IntentMatcher] No match found, using fallback response");
        return new ChatMessage(
            ChatMessage.Sender.BOT,
            FALLBACK_RESPONSES[RANDOM.nextInt(FALLBACK_RESPONSES.length)],
            0.0, "fallback"
        );
    }

    /**
     * Checks if the engine has been trained.
     */
    public boolean isTrained() {
        return similarityEngine.isTrained();
    }
}
