package com.securevision.chatbot.nlp;

import java.util.List;

/**
 * NLPProcessor - Orchestrates the full NLP pipeline.
 * 
 * Pipeline: raw text → tokenize → remove stop words → stem
 * 
 * This is the central class that other components use to process text.
 * It chains together all NLP stages in the correct order.
 */
public class NLPProcessor {

    private final Tokenizer tokenizer;
    private final StopWordRemover stopWordRemover;
    private final PorterStemmer stemmer;

    public NLPProcessor() {
        this.tokenizer = new Tokenizer();
        this.stopWordRemover = new StopWordRemover();
        this.stemmer = new PorterStemmer();
    }

    /**
     * Runs the full NLP pipeline on raw text input.
     * 
     * @param rawText The raw user input
     * @return Processed tokens (tokenized, stop-words removed, stemmed)
     */
    public List<String> process(String rawText) {
        // Step 1: Tokenize (lowercase, handle contractions, remove punctuation)
        List<String> tokens = tokenizer.tokenize(rawText);
        
        // Step 2: Remove stop words
        List<String> filtered = stopWordRemover.removeStopWords(tokens);
        
        // Step 3: Stem words to root form
        List<String> stemmed = stemmer.stemTokens(filtered);
        
        return stemmed;
    }

    /**
     * Tokenizes text without stemming (useful for rule-based matching).
     * 
     * @param rawText The raw user input
     * @return Tokenized list (lowercase, contractions expanded)
     */
    public List<String> tokenizeOnly(String rawText) {
        return tokenizer.tokenize(rawText);
    }

    /**
     * Returns cleaned text (tokenized and joined, no stemming).
     * 
     * @param rawText The raw user input
     * @return Cleaned string
     */
    public String clean(String rawText) {
        return tokenizer.cleanText(rawText);
    }

    // Expose individual components for advanced usage
    public Tokenizer getTokenizer() { return tokenizer; }
    public StopWordRemover getStopWordRemover() { return stopWordRemover; }
    public PorterStemmer getStemmer() { return stemmer; }
}
