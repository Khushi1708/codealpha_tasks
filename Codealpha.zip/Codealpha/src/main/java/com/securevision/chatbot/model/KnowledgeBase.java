package com.securevision.chatbot.model;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * KnowledgeBase - Loads and manages FAQ intents from a JSON file.
 * 
 * Handles JSON parsing manually (no external libraries) to keep the
 * project dependency-free. Provides access to all intents for training
 * and querying.
 */
public class KnowledgeBase {

    private List<Intent> intents;
    private Map<String, Intent> intentMap;  // tag -> Intent lookup

    public KnowledgeBase() {
        this.intents = new ArrayList<>();
        this.intentMap = new HashMap<>();
    }

    /**
     * Loads the knowledge base from a JSON file.
     *
     * @param filePath Path to the knowledge_base.json file
     * @throws IOException if the file cannot be read
     */
    public void loadFromFile(String filePath) throws IOException {
        String json = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
        parseJson(json);
        System.out.println("[KnowledgeBase] Loaded " + intents.size() + " intents from " + filePath);
    }

    /**
     * Loads from an InputStream (for classpath resources).
     */
    public void loadFromStream(InputStream stream) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        parseJson(sb.toString());
        System.out.println("[KnowledgeBase] Loaded " + intents.size() + " intents from stream");
    }

    /**
     * Returns all intents in the knowledge base.
     */
    public List<Intent> getIntents() {
        return Collections.unmodifiableList(intents);
    }

    /**
     * Looks up an intent by its tag.
     */
    public Intent getIntentByTag(String tag) {
        return intentMap.get(tag);
    }

    /**
     * Returns all unique categories.
     */
    public Set<String> getCategories() {
        Set<String> categories = new LinkedHashSet<>();
        for (Intent intent : intents) {
            categories.add(intent.getCategory());
        }
        return categories;
    }

    /**
     * Returns all training phrases across all intents (for TF-IDF corpus building).
     */
    public List<String> getAllTrainingPhrases() {
        List<String> phrases = new ArrayList<>();
        for (Intent intent : intents) {
            phrases.addAll(intent.getTrainingPhrases());
        }
        return phrases;
    }

    /**
     * Returns a mapping of phrase index to intent (for matching results back).
     */
    public Map<Integer, Intent> getPhraseToIntentMap() {
        Map<Integer, Intent> map = new HashMap<>();
        int idx = 0;
        for (Intent intent : intents) {
            for (int i = 0; i < intent.getTrainingPhrases().size(); i++) {
                map.put(idx++, intent);
            }
        }
        return map;
    }

    // --- JSON Parser (Manual, no external libraries) ---

    private void parseJson(String json) {
        intents = new ArrayList<>();
        intentMap = new HashMap<>();

        // Find the "intents" array
        int intentsStart = json.indexOf("\"intents\"");
        if (intentsStart == -1) return;

        int arrayStart = json.indexOf("[", intentsStart);
        if (arrayStart == -1) return;

        // Find matching closing bracket
        int arrayEnd = findMatchingBracket(json, arrayStart);
        String intentsArray = json.substring(arrayStart + 1, arrayEnd);

        // Parse each intent object
        int pos = 0;
        while (pos < intentsArray.length()) {
            int objStart = intentsArray.indexOf("{", pos);
            if (objStart == -1) break;

            int objEnd = findMatchingBrace(intentsArray, objStart);
            String objStr = intentsArray.substring(objStart, objEnd + 1);

            Intent intent = parseIntentObject(objStr);
            if (intent != null && intent.getTag() != null) {
                intents.add(intent);
                intentMap.put(intent.getTag(), intent);
            }

            pos = objEnd + 1;
        }
    }

    private Intent parseIntentObject(String json) {
        Intent intent = new Intent();

        intent.setTag(extractStringValue(json, "tag"));
        intent.setCategory(extractStringValue(json, "category"));
        intent.setTrainingPhrases(extractStringArray(json, "training_phrases"));
        intent.setResponses(extractStringArray(json, "responses"));

        return intent;
    }

    private String extractStringValue(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx == -1) return null;

        int colonIdx = json.indexOf(":", keyIdx + searchKey.length());
        if (colonIdx == -1) return null;

        int valueStart = json.indexOf("\"", colonIdx + 1);
        if (valueStart == -1) return null;

        int valueEnd = findClosingQuote(json, valueStart + 1);
        if (valueEnd == -1) return null;

        return unescapeJson(json.substring(valueStart + 1, valueEnd));
    }

    private List<String> extractStringArray(String json, String key) {
        List<String> result = new ArrayList<>();
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx == -1) return result;

        int arrayStart = json.indexOf("[", keyIdx);
        if (arrayStart == -1) return result;

        int arrayEnd = findMatchingBracket(json, arrayStart);
        String arrayContent = json.substring(arrayStart + 1, arrayEnd);

        int pos = 0;
        while (pos < arrayContent.length()) {
            int strStart = arrayContent.indexOf("\"", pos);
            if (strStart == -1) break;

            int strEnd = findClosingQuote(arrayContent, strStart + 1);
            if (strEnd == -1) break;

            result.add(unescapeJson(arrayContent.substring(strStart + 1, strEnd)));
            pos = strEnd + 1;
        }

        return result;
    }

    private int findMatchingBracket(String text, int openPos) {
        int depth = 1;
        boolean inString = false;
        for (int i = openPos + 1; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\' && inString) { i++; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (!inString) {
                if (c == '[') depth++;
                if (c == ']') { depth--; if (depth == 0) return i; }
            }
        }
        return text.length() - 1;
    }

    private int findMatchingBrace(String text, int openPos) {
        int depth = 1;
        boolean inString = false;
        for (int i = openPos + 1; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\\' && inString) { i++; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (!inString) {
                if (c == '{') depth++;
                if (c == '}') { depth--; if (depth == 0) return i; }
            }
        }
        return text.length() - 1;
    }

    private int findClosingQuote(String text, int startPos) {
        for (int i = startPos; i < text.length(); i++) {
            if (text.charAt(i) == '\\') { i++; continue; }
            if (text.charAt(i) == '"') return i;
        }
        return -1;
    }

    private String unescapeJson(String text) {
        return text
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t");
    }
}
