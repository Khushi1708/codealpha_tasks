package com.securevision.chatbot.engine;

import com.securevision.chatbot.model.Intent;
import com.securevision.chatbot.model.KnowledgeBase;
import com.securevision.chatbot.nlp.NLPProcessor;
import com.securevision.chatbot.nlp.TFIDFVectorizer;

import java.util.*;

/**
 * SimilarityEngine - ML-style intent matching using TF-IDF and cosine similarity.
 * 
 * This engine:
 * 1. Processes all FAQ training phrases through the NLP pipeline
 * 2. Builds TF-IDF vectors for the entire corpus
 * 3. Compares user input vectors against corpus vectors using cosine similarity
 * 4. Returns the best-matching intent above a confidence threshold
 */
public class SimilarityEngine {

    private final NLPProcessor nlpProcessor;
    private final TFIDFVectorizer vectorizer;
    private final double confidenceThreshold;

    // Corpus data
    private List<double[]> corpusVectors;
    private Map<Integer, Intent> phraseToIntentMap;
    private boolean isTrained = false;

    /**
     * Creates a SimilarityEngine with a default confidence threshold of 0.25.
     */
    public SimilarityEngine(NLPProcessor nlpProcessor) {
        this(nlpProcessor, 0.25);
    }

    /**
     * Creates a SimilarityEngine with a custom confidence threshold.
     *
     * @param nlpProcessor    The NLP processor for text processing
     * @param confidenceThreshold Minimum similarity score to consider a match (0.0-1.0)
     */
    public SimilarityEngine(NLPProcessor nlpProcessor, double confidenceThreshold) {
        this.nlpProcessor = nlpProcessor;
        this.vectorizer = new TFIDFVectorizer();
        this.confidenceThreshold = confidenceThreshold;
        this.corpusVectors = new ArrayList<>();
    }

    /**
     * Trains the similarity engine on the knowledge base.
     * This processes all training phrases through NLP and builds TF-IDF vectors.
     *
     * @param knowledgeBase The loaded knowledge base with FAQ intents
     */
    public void train(KnowledgeBase knowledgeBase) {
        System.out.println("[SimilarityEngine] Training on knowledge base...");

        // Build the phrase-to-intent mapping
        phraseToIntentMap = knowledgeBase.getPhraseToIntentMap();

        // Process all training phrases through NLP pipeline
        List<List<String>> processedCorpus = new ArrayList<>();
        List<String> allPhrases = knowledgeBase.getAllTrainingPhrases();

        for (String phrase : allPhrases) {
            List<String> processed = nlpProcessor.process(phrase);
            processedCorpus.add(processed);
        }

        // Train the TF-IDF vectorizer
        vectorizer.fit(processedCorpus);

        // Build corpus vectors
        corpusVectors = vectorizer.transformCorpus();

        isTrained = true;
        System.out.println("[SimilarityEngine] Training complete. Vocabulary size: " 
            + vectorizer.getVocabularySize() + ", Documents: " + corpusVectors.size());
    }

    /**
     * Finds the best-matching intent for a user query.
     *
     * @param userInput Raw user input text
     * @return MatchResult with the best intent and confidence, or null if no match
     */
    public MatchResult findBestMatch(String userInput) {
        if (!isTrained) {
            throw new IllegalStateException("SimilarityEngine has not been trained. Call train() first.");
        }

        // Process user input through the same NLP pipeline
        List<String> processedInput = nlpProcessor.process(userInput);

        if (processedInput.isEmpty()) {
            return null;
        }

        // Transform to TF-IDF vector
        double[] inputVector = vectorizer.transform(processedInput);

        // Find the best matching document
        double bestScore = -1;
        int bestIndex = -1;

        for (int i = 0; i < corpusVectors.size(); i++) {
            double similarity = TFIDFVectorizer.cosineSimilarity(inputVector, corpusVectors.get(i));
            if (similarity > bestScore) {
                bestScore = similarity;
                bestIndex = i;
            }
        }

        // Check threshold
        if (bestScore >= confidenceThreshold && bestIndex >= 0) {
            Intent matchedIntent = phraseToIntentMap.get(bestIndex);
            if (matchedIntent != null) {
                return new MatchResult(matchedIntent, bestScore);
            }
        }

        return null;
    }

    /**
     * Returns the top N matches for debugging and transparency.
     */
    public List<MatchResult> findTopMatches(String userInput, int topN) {
        if (!isTrained) return Collections.emptyList();

        List<String> processedInput = nlpProcessor.process(userInput);
        if (processedInput.isEmpty()) return Collections.emptyList();

        double[] inputVector = vectorizer.transform(processedInput);

        // Score all documents
        List<MatchResult> results = new ArrayList<>();
        Map<String, MatchResult> bestPerIntent = new LinkedHashMap<>();

        for (int i = 0; i < corpusVectors.size(); i++) {
            double similarity = TFIDFVectorizer.cosineSimilarity(inputVector, corpusVectors.get(i));
            Intent intent = phraseToIntentMap.get(i);

            if (intent != null) {
                String tag = intent.getTag();
                MatchResult existing = bestPerIntent.get(tag);
                if (existing == null || similarity > existing.confidence) {
                    bestPerIntent.put(tag, new MatchResult(intent, similarity));
                }
            }
        }

        results.addAll(bestPerIntent.values());
        results.sort((a, b) -> Double.compare(b.confidence, a.confidence));

        return results.subList(0, Math.min(topN, results.size()));
    }

    public boolean isTrained() { return isTrained; }
    public double getConfidenceThreshold() { return confidenceThreshold; }

    /**
     * Result of a similarity match.
     */
    public static class MatchResult {
        public final Intent intent;
        public final double confidence;

        public MatchResult(Intent intent, double confidence) {
            this.intent = intent;
            this.confidence = confidence;
        }

        @Override
        public String toString() {
            return String.format("MatchResult{intent='%s', confidence=%.4f}", 
                intent.getTag(), confidence);
        }
    }
}
