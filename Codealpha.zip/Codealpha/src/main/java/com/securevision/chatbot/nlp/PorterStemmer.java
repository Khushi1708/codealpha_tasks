package com.securevision.chatbot.nlp;

import java.util.ArrayList;
import java.util.List;

/**
 * PorterStemmer - Implements the Porter Stemming Algorithm in pure Java.
 * 
 * The Porter stemmer reduces words to their root form by applying a series
 * of suffix-stripping rules. For example:
 *   "running"  -> "run"
 *   "payments" -> "payment"
 *   "happiness" -> "happi"
 *   "connected" -> "connect"
 * 
 * Reference: M.F. Porter, "An algorithm for suffix stripping", Program, 1980.
 */
public class PorterStemmer {

    /**
     * Stems a single word using the Porter algorithm.
     *
     * @param word The word to stem
     * @return The stemmed word
     */
    public String stem(String word) {
        if (word == null || word.length() < 3) {
            return word;
        }

        String result = word.toLowerCase();

        // Step 1a: Plurals
        result = step1a(result);
        // Step 1b: Past tenses
        result = step1b(result);
        // Step 1c: Y suffix
        result = step1c(result);
        // Step 2: Derivational suffixes
        result = step2(result);
        // Step 3: Derivational suffixes
        result = step3(result);
        // Step 4: Derivational suffixes
        result = step4(result);
        // Step 5a
        result = step5a(result);
        // Step 5b
        result = step5b(result);

        return result;
    }

    /**
     * Stems a list of tokens.
     *
     * @param tokens List of word tokens
     * @return List of stemmed tokens
     */
    public List<String> stemTokens(List<String> tokens) {
        List<String> stemmed = new ArrayList<>();
        for (String token : tokens) {
            stemmed.add(stem(token));
        }
        return stemmed;
    }

    // --- Porter Algorithm Steps ---

    private String step1a(String word) {
        if (word.endsWith("sses")) {
            return word.substring(0, word.length() - 2);
        } else if (word.endsWith("ies")) {
            return word.substring(0, word.length() - 2);
        } else if (!word.endsWith("ss") && word.endsWith("s")) {
            return word.substring(0, word.length() - 1);
        }
        return word;
    }

    private String step1b(String word) {
        if (word.endsWith("eed")) {
            String stem = word.substring(0, word.length() - 3);
            if (measure(stem) > 0) {
                return word.substring(0, word.length() - 1);
            }
            return word;
        }

        boolean modified = false;
        String stem = word;

        if (word.endsWith("ed")) {
            stem = word.substring(0, word.length() - 2);
            if (containsVowel(stem)) {
                modified = true;
            } else {
                stem = word;
            }
        } else if (word.endsWith("ing")) {
            stem = word.substring(0, word.length() - 3);
            if (containsVowel(stem)) {
                modified = true;
            } else {
                stem = word;
            }
        }

        if (modified) {
            if (stem.endsWith("at") || stem.endsWith("bl") || stem.endsWith("iz")) {
                stem = stem + "e";
            } else if (endsWithDouble(stem) && !stem.endsWith("l") 
                       && !stem.endsWith("s") && !stem.endsWith("z")) {
                stem = stem.substring(0, stem.length() - 1);
            } else if (measure(stem) == 1 && endsWithCVC(stem)) {
                stem = stem + "e";
            }
        }

        return stem;
    }

    private String step1c(String word) {
        if (word.endsWith("y") && containsVowel(word.substring(0, word.length() - 1))) {
            return word.substring(0, word.length() - 1) + "i";
        }
        return word;
    }

    private String step2(String word) {
        String[][] suffixes = {
            {"ational", "ate"}, {"tional", "tion"}, {"enci", "ence"},
            {"anci", "ance"}, {"izer", "ize"}, {"abli", "able"},
            {"alli", "al"}, {"entli", "ent"}, {"eli", "e"},
            {"ousli", "ous"}, {"ization", "ize"}, {"ation", "ate"},
            {"ator", "ate"}, {"alism", "al"}, {"iveness", "ive"},
            {"fulness", "ful"}, {"ousness", "ous"}, {"aliti", "al"},
            {"iviti", "ive"}, {"biliti", "ble"}, {"logi", "log"}
        };

        for (String[] pair : suffixes) {
            if (word.endsWith(pair[0])) {
                String stem = word.substring(0, word.length() - pair[0].length());
                if (measure(stem) > 0) {
                    return stem + pair[1];
                }
                return word;
            }
        }
        return word;
    }

    private String step3(String word) {
        String[][] suffixes = {
            {"icate", "ic"}, {"ative", ""}, {"alize", "al"},
            {"iciti", "ic"}, {"ical", "ic"}, {"ful", ""},
            {"ness", ""}
        };

        for (String[] pair : suffixes) {
            if (word.endsWith(pair[0])) {
                String stem = word.substring(0, word.length() - pair[0].length());
                if (measure(stem) > 0) {
                    return stem + pair[1];
                }
                return word;
            }
        }
        return word;
    }

    private String step4(String word) {
        String[] suffixes = {
            "al", "ance", "ence", "er", "ic", "able", "ible", "ant",
            "ement", "ment", "ent", "ion", "ou", "ism", "ate", "iti",
            "ous", "ive", "ize"
        };

        for (String suffix : suffixes) {
            if (word.endsWith(suffix)) {
                String stem = word.substring(0, word.length() - suffix.length());
                if (measure(stem) > 1) {
                    if (suffix.equals("ion")) {
                        if (stem.length() > 0 && (stem.endsWith("s") || stem.endsWith("t"))) {
                            return stem;
                        }
                    } else {
                        return stem;
                    }
                }
            }
        }
        return word;
    }

    private String step5a(String word) {
        if (word.endsWith("e")) {
            String stem = word.substring(0, word.length() - 1);
            if (measure(stem) > 1) {
                return stem;
            }
            if (measure(stem) == 1 && !endsWithCVC(stem)) {
                return stem;
            }
        }
        return word;
    }

    private String step5b(String word) {
        if (measure(word) > 1 && endsWithDouble(word) && word.endsWith("l")) {
            return word.substring(0, word.length() - 1);
        }
        return word;
    }

    // --- Helper Methods ---

    private boolean isVowel(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }

    private boolean isVowelAt(String word, int index) {
        char c = word.charAt(index);
        if (isVowel(c)) return true;
        if (c == 'y' && index > 0) return !isVowel(word.charAt(index - 1));
        return false;
    }

    /**
     * Calculates the "measure" of a word - the number of VC (vowel-consonant) 
     * sequences in the word.
     */
    private int measure(String word) {
        if (word == null || word.isEmpty()) return 0;

        int count = 0;
        boolean prevVowel = false;

        for (int i = 0; i < word.length(); i++) {
            boolean currVowel = isVowelAt(word, i);
            if (!currVowel && prevVowel) {
                count++;
            }
            prevVowel = currVowel;
        }

        return count;
    }

    private boolean containsVowel(String word) {
        for (int i = 0; i < word.length(); i++) {
            if (isVowelAt(word, i)) return true;
        }
        return false;
    }

    private boolean endsWithDouble(String word) {
        if (word.length() < 2) return false;
        return word.charAt(word.length() - 1) == word.charAt(word.length() - 2);
    }

    /**
     * Checks if the word ends with a consonant-vowel-consonant pattern
     * where the final consonant is not w, x, or y.
     */
    private boolean endsWithCVC(String word) {
        if (word.length() < 3) return false;

        int len = word.length();
        char c3 = word.charAt(len - 1);
        char c2 = word.charAt(len - 2);
        char c1 = word.charAt(len - 3);

        if (c3 == 'w' || c3 == 'x' || c3 == 'y') return false;

        return !isVowelAt(word, len - 1) 
            && isVowelAt(word, len - 2) 
            && !isVowelAt(word, len - 3);
    }
}
