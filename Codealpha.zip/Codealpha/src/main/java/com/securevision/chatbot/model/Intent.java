package com.securevision.chatbot.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Intent - Represents a single intent (topic/question) in the knowledge base.
 * 
 * Each intent contains:
 * - A unique tag/identifier
 * - A category for grouping
 * - Multiple training phrases (different ways to ask the same question)
 * - Multiple response variants (for natural, varied replies)
 */
public class Intent {

    private String tag;
    private String category;
    private List<String> trainingPhrases;
    private List<String> responses;
    private static final Random RANDOM = new Random();

    public Intent() {
        this.trainingPhrases = new ArrayList<>();
        this.responses = new ArrayList<>();
    }

    public Intent(String tag, String category, List<String> trainingPhrases, List<String> responses) {
        this.tag = tag;
        this.category = category;
        this.trainingPhrases = trainingPhrases != null ? trainingPhrases : new ArrayList<>();
        this.responses = responses != null ? responses : new ArrayList<>();
    }

    // Getters and Setters
    public String getTag() { return tag; }
    public void setTag(String tag) { this.tag = tag; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public List<String> getTrainingPhrases() { return trainingPhrases; }
    public void setTrainingPhrases(List<String> trainingPhrases) { this.trainingPhrases = trainingPhrases; }

    public List<String> getResponses() { return responses; }
    public void setResponses(List<String> responses) { this.responses = responses; }

    /**
     * Returns a random response from the available variants.
     * This creates more natural, less repetitive conversations.
     */
    public String getRandomResponse() {
        if (responses.isEmpty()) {
            return "I'm not sure how to respond to that.";
        }
        return responses.get(RANDOM.nextInt(responses.size()));
    }

    /**
     * Adds a training phrase to this intent.
     */
    public void addTrainingPhrase(String phrase) {
        trainingPhrases.add(phrase);
    }

    /**
     * Adds a response variant to this intent.
     */
    public void addResponse(String response) {
        responses.add(response);
    }

    @Override
    public String toString() {
        return String.format("Intent{tag='%s', category='%s', phrases=%d, responses=%d}",
            tag, category, trainingPhrases.size(), responses.size());
    }
}
