package com.securevision.chatbot;

import com.securevision.chatbot.engine.IntentMatcher;
import com.securevision.chatbot.model.ChatMessage;
import com.securevision.chatbot.model.KnowledgeBase;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * ChatbotServer — Main entry point for the SecureVision AI Chatbot.
 * 
 * Uses Java's built-in HttpServer (no external dependencies) to:
 * - Serve the web interface (HTML/CSS/JS) on port 8080
 * - Expose a REST API endpoint at POST /api/chat
 * - Expose a health check at GET /api/health
 * 
 * Architecture:
 * 1. Loads the FAQ knowledge base from JSON
 * 2. Trains the NLP/ML intent matching engine
 * 3. Starts the HTTP server
 * 4. Processes chat messages through the NLP pipeline
 */
public class ChatbotServer {

    private static final int PORT = 8080;
    private static final String WEB_ROOT = "web";
    private static IntentMatcher intentMatcher;
    private static String resourceBase;

    // MIME type mapping
    private static final Map<String, String> MIME_TYPES = new HashMap<>();
    static {
        MIME_TYPES.put("html", "text/html; charset=UTF-8");
        MIME_TYPES.put("css", "text/css; charset=UTF-8");
        MIME_TYPES.put("js", "application/javascript; charset=UTF-8");
        MIME_TYPES.put("json", "application/json; charset=UTF-8");
        MIME_TYPES.put("png", "image/png");
        MIME_TYPES.put("jpg", "image/jpeg");
        MIME_TYPES.put("svg", "image/svg+xml");
        MIME_TYPES.put("ico", "image/x-icon");
    }

    public static void main(String[] args) throws Exception {
        System.out.println("╔══════════════════════════════════════════════════╗");
        System.out.println("║          SecureVision AI Chatbot Server          ║");
        System.out.println("║       Java NLP • TF-IDF • Cosine Similarity     ║");
        System.out.println("╚══════════════════════════════════════════════════╝");
        System.out.println();

        // Determine resource base directory
        resourceBase = findResourceBase();
        System.out.println("[Server] Resource base: " + resourceBase);

        // Load Knowledge Base
        System.out.println("[Server] Loading knowledge base...");
        KnowledgeBase kb = new KnowledgeBase();
        String kbPath = resourceBase + File.separator + "knowledge_base.json";
        kb.loadFromFile(kbPath);
        System.out.println("[Server] Categories: " + kb.getCategories());
        System.out.println("[Server] Total training phrases: " + kb.getAllTrainingPhrases().size());

        // Initialize and train the Intent Matcher
        System.out.println("[Server] Training NLP engine...");
        intentMatcher = new IntentMatcher();
        intentMatcher.train(kb);
        System.out.println("[Server] NLP engine trained successfully!");
        System.out.println();

        // Start HTTP Server
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/api/chat", new ChatHandler());
        server.createContext("/api/health", new HealthHandler());
        server.createContext("/", new StaticFileHandler());
        server.setExecutor(Executors.newFixedThreadPool(10));
        server.start();

        System.out.println("═══════════════════════════════════════════════════");
        System.out.println("  🚀 Server started successfully!");
        System.out.println("  🌐 Open in browser: http://localhost:" + PORT);
        System.out.println("  📡 API endpoint:    http://localhost:" + PORT + "/api/chat");
        System.out.println("  ⏹️  Press Ctrl+C to stop");
        System.out.println("═══════════════════════════════════════════════════");
        System.out.println();

        // Shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\n[Server] Shutting down...");
            server.stop(1);
            System.out.println("[Server] Server stopped. Goodbye! 👋");
        }));
    }

    /**
     * Finds the resources directory relative to the working directory.
     */
    private static String findResourceBase() {
        // Try several possible locations
        String[] candidates = {
            "src" + File.separator + "resources",
            "resources",
            "src" + File.separator + "main" + File.separator + "resources",
            "."
        };

        for (String candidate : candidates) {
            File dir = new File(candidate);
            if (dir.exists() && new File(dir, "knowledge_base.json").exists()) {
                return dir.getAbsolutePath();
            }
        }

        // Default fallback
        return "src" + File.separator + "resources";
    }

    // ========================================
    // Chat API Handler — POST /api/chat
    // ========================================
    static class ChatHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // CORS headers
            setCorsHeaders(exchange);

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendError(exchange, 405, "Method not allowed. Use POST.");
                return;
            }

            try {
                // Read request body
                String body = readRequestBody(exchange);
                String userMessage = extractJsonValue(body, "message");

                if (userMessage == null || userMessage.trim().isEmpty()) {
                    sendError(exchange, 400, "Missing 'message' field in request body.");
                    return;
                }

                System.out.println("[Chat] User: " + userMessage);

                // Process through NLP pipeline
                ChatMessage response = intentMatcher.processInput(userMessage);

                System.out.println("[Chat] Bot: " + response.getContent().substring(0, 
                    Math.min(80, response.getContent().length())) + "...");
                System.out.println();

                // Send response
                String jsonResponse = response.toJson();
                sendJsonResponse(exchange, 200, jsonResponse);

            } catch (Exception e) {
                System.err.println("[Chat] Error processing message: " + e.getMessage());
                e.printStackTrace();
                sendError(exchange, 500, "Internal server error: " + e.getMessage());
            }
        }
    }

    // ========================================
    // Health Check — GET /api/health
    // ========================================
    static class HealthHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            setCorsHeaders(exchange);
            String response = "{\"status\":\"healthy\",\"engine\":\"trained\",\"version\":\"1.0.0\"}";
            sendJsonResponse(exchange, 200, response);
        }
    }

    // ========================================
    // Static File Handler — Serves web UI
    // ========================================
    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();

            // Default to index.html
            if (path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            // Security: prevent directory traversal
            if (path.contains("..")) {
                sendError(exchange, 403, "Forbidden");
                return;
            }

            // Build file path
            String filePath = resourceBase + File.separator + WEB_ROOT + path.replace("/", File.separator);
            File file = new File(filePath);

            if (!file.exists() || !file.isFile()) {
                // Fallback to index.html for SPA routing
                filePath = resourceBase + File.separator + WEB_ROOT + File.separator + "index.html";
                file = new File(filePath);
                if (!file.exists()) {
                    sendError(exchange, 404, "File not found: " + path);
                    return;
                }
            }

            // Determine MIME type
            String ext = getFileExtension(file.getName());
            String mimeType = MIME_TYPES.getOrDefault(ext, "application/octet-stream");

            // Read and serve file
            byte[] fileBytes = Files.readAllBytes(file.toPath());
            exchange.getResponseHeaders().set("Content-Type", mimeType);
            exchange.getResponseHeaders().set("Cache-Control", "no-cache");
            exchange.sendResponseHeaders(200, fileBytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(fileBytes);
            }
        }
    }

    // ========================================
    // Utility Methods
    // ========================================

    private static void setCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
    }

    private static String readRequestBody(HttpExchange exchange) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        }
    }

    /**
     * Simple JSON value extractor (no external library needed).
     */
    private static String extractJsonValue(String json, String key) {
        String searchKey = "\"" + key + "\"";
        int keyIdx = json.indexOf(searchKey);
        if (keyIdx == -1) return null;

        int colonIdx = json.indexOf(":", keyIdx + searchKey.length());
        if (colonIdx == -1) return null;

        // Find the value (string)
        int valueStart = json.indexOf("\"", colonIdx + 1);
        if (valueStart == -1) return null;

        int valueEnd = valueStart + 1;
        while (valueEnd < json.length()) {
            if (json.charAt(valueEnd) == '\\') {
                valueEnd += 2; // Skip escaped character
                continue;
            }
            if (json.charAt(valueEnd) == '"') break;
            valueEnd++;
        }

        if (valueEnd >= json.length()) return null;

        return json.substring(valueStart + 1, valueEnd)
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\t", "\t");
    }

    private static void sendJsonResponse(HttpExchange exchange, int statusCode, String json)
            throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static void sendError(HttpExchange exchange, int statusCode, String message)
            throws IOException {
        String json = "{\"error\":\"" + message.replace("\"", "'") + "\"}";
        sendJsonResponse(exchange, statusCode, json);
    }

    private static String getFileExtension(String fileName) {
        int dotIdx = fileName.lastIndexOf('.');
        if (dotIdx == -1 || dotIdx == fileName.length() - 1) return "";
        return fileName.substring(dotIdx + 1).toLowerCase();
    }
}
