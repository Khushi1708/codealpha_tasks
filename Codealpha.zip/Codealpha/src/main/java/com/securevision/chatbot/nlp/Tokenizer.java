package com.securevision.chatbot.nlp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tokenizer - Splits raw text input into normalized word tokens.
 * 
 * Features:
 * - Lowercase normalization
 * - Contraction expansion (e.g., "don't" -> "do", "not")
 * - Punctuation removal
 * - Number preservation
 */
public class Tokenizer {

    private static final Pattern WORD_PATTERN = Pattern.compile("[a-zA-Z0-9]+(?:'[a-zA-Z]+)?");
    private static final Map<String, String[]> CONTRACTIONS = new HashMap<>();

    static {
        // Common English contractions
        CONTRACTIONS.put("don't", new String[]{"do", "not"});
        CONTRACTIONS.put("doesn't", new String[]{"does", "not"});
        CONTRACTIONS.put("didn't", new String[]{"did", "not"});
        CONTRACTIONS.put("won't", new String[]{"will", "not"});
        CONTRACTIONS.put("wouldn't", new String[]{"would", "not"});
        CONTRACTIONS.put("shouldn't", new String[]{"should", "not"});
        CONTRACTIONS.put("couldn't", new String[]{"could", "not"});
        CONTRACTIONS.put("can't", new String[]{"can", "not"});
        CONTRACTIONS.put("isn't", new String[]{"is", "not"});
        CONTRACTIONS.put("aren't", new String[]{"are", "not"});
        CONTRACTIONS.put("wasn't", new String[]{"was", "not"});
        CONTRACTIONS.put("weren't", new String[]{"were", "not"});
        CONTRACTIONS.put("hasn't", new String[]{"has", "not"});
        CONTRACTIONS.put("haven't", new String[]{"have", "not"});
        CONTRACTIONS.put("hadn't", new String[]{"had", "not"});
        CONTRACTIONS.put("i'm", new String[]{"i", "am"});
        CONTRACTIONS.put("you're", new String[]{"you", "are"});
        CONTRACTIONS.put("we're", new String[]{"we", "are"});
        CONTRACTIONS.put("they're", new String[]{"they", "are"});
        CONTRACTIONS.put("he's", new String[]{"he", "is"});
        CONTRACTIONS.put("she's", new String[]{"she", "is"});
        CONTRACTIONS.put("it's", new String[]{"it", "is"});
        CONTRACTIONS.put("that's", new String[]{"that", "is"});
        CONTRACTIONS.put("what's", new String[]{"what", "is"});
        CONTRACTIONS.put("who's", new String[]{"who", "is"});
        CONTRACTIONS.put("there's", new String[]{"there", "is"});
        CONTRACTIONS.put("here's", new String[]{"here", "is"});
        CONTRACTIONS.put("where's", new String[]{"where", "is"});
        CONTRACTIONS.put("i've", new String[]{"i", "have"});
        CONTRACTIONS.put("you've", new String[]{"you", "have"});
        CONTRACTIONS.put("we've", new String[]{"we", "have"});
        CONTRACTIONS.put("they've", new String[]{"they", "have"});
        CONTRACTIONS.put("i'll", new String[]{"i", "will"});
        CONTRACTIONS.put("you'll", new String[]{"you", "will"});
        CONTRACTIONS.put("we'll", new String[]{"we", "will"});
        CONTRACTIONS.put("they'll", new String[]{"they", "will"});
        CONTRACTIONS.put("i'd", new String[]{"i", "would"});
        CONTRACTIONS.put("you'd", new String[]{"you", "would"});
        CONTRACTIONS.put("we'd", new String[]{"we", "would"});
        CONTRACTIONS.put("they'd", new String[]{"they", "would"});
        CONTRACTIONS.put("let's", new String[]{"let", "us"});
    }

    /**
     * Tokenizes the input text into a list of normalized word tokens.
     *
     * @param text The raw input text
     * @return A list of lowercase word tokens with contractions expanded
     */
    public List<String> tokenize(String text) {
        if (text == null || text.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String normalized = text.toLowerCase().trim();
        List<String> tokens = new ArrayList<>();
        Matcher matcher = WORD_PATTERN.matcher(normalized);

        while (matcher.find()) {
            String token = matcher.group();

            // Check for contractions
            if (CONTRACTIONS.containsKey(token)) {
                String[] expanded = CONTRACTIONS.get(token);
                for (String word : expanded) {
                    tokens.add(word);
                }
            } else {
                // Remove trailing apostrophe fragments
                token = token.replaceAll("'.*$", "");
                if (!token.isEmpty()) {
                    tokens.add(token);
                }
            }
        }

        return tokens;
    }

    /**
     * Tokenizes and joins back into a cleaned string.
     *
     * @param text The raw input text
     * @return Cleaned, normalized text string
     */
    public String cleanText(String text) {
        return String.join(" ", tokenize(text));
    }
}
