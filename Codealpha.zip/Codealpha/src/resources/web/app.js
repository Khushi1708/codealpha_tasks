/**
 * SecureVision AI Chatbot — Frontend Application
 * 
 * Handles:
 * - Message sending/receiving via REST API
 * - Dynamic message rendering with animations
 * - Typing indicator simulation
 * - Quick action buttons
 * - Sidebar navigation
 * - Particle background animation
 * - Auto-scroll and keyboard shortcuts
 */

(function () {
    'use strict';

    // --- Configuration ---
    const CONFIG = {
        API_URL: '/api/chat',
        TYPING_DELAY_MIN: 600,
        TYPING_DELAY_MAX: 1500,
        MAX_MESSAGE_LENGTH: 1000,
        PARTICLE_COUNT: 30,
    };

    // --- DOM Elements ---
    const elements = {
        messagesScroll: document.getElementById('messages-scroll'),
        messageInput: document.getElementById('message-input'),
        sendBtn: document.getElementById('send-btn'),
        welcomeScreen: document.getElementById('welcome-screen'),
        quickActions: document.getElementById('quick-actions'),
        sidebar: document.getElementById('sidebar'),
        menuToggle: document.getElementById('menu-toggle'),
        btnNewChat: document.getElementById('btn-new-chat'),
        btnTopics: document.getElementById('btn-topics'),
        btnHelp: document.getElementById('btn-help'),
        btnClear: document.getElementById('btn-clear'),
        statusDot: document.querySelector('.status-dot'),
        statusText: document.querySelector('.status-text'),
        statMessages: document.getElementById('stat-messages'),
        statConfidence: document.getElementById('stat-confidence'),
        particles: document.getElementById('particles'),
    };

    // --- State ---
    let state = {
        messageCount: 0,
        totalConfidence: 0,
        botResponses: 0,
        isTyping: false,
        sidebarOpen: false,
    };

    // --- Initialize ---
    function init() {
        createParticles();
        bindEvents();
        checkServerStatus();
        elements.messageInput.focus();
    }

    // --- Particle Animation ---
    function createParticles() {
        const colors = ['#6C63FF', '#00D2FF', '#A855F7', '#818cf8', '#38bdf8'];
        for (let i = 0; i < CONFIG.PARTICLE_COUNT; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 8 + 's';
            particle.style.animationDuration = (6 + Math.random() * 6) + 's';
            particle.style.width = (2 + Math.random() * 3) + 'px';
            particle.style.height = particle.style.width;
            particle.style.background = colors[Math.floor(Math.random() * colors.length)];
            elements.particles.appendChild(particle);
        }
    }

    // --- Event Binding ---
    function bindEvents() {
        // Send button
        elements.sendBtn.addEventListener('click', handleSend);

        // Textarea input
        elements.messageInput.addEventListener('input', handleInputChange);
        elements.messageInput.addEventListener('keydown', handleKeyDown);

        // Quick action buttons
        elements.quickActions.addEventListener('click', function (e) {
            const btn = e.target.closest('.quick-btn');
            if (btn) {
                const message = btn.getAttribute('data-message');
                if (message) sendMessage(message);
            }
        });

        // Sidebar buttons
        elements.menuToggle.addEventListener('click', toggleSidebar);
        elements.btnNewChat.addEventListener('click', clearChat);
        elements.btnTopics.addEventListener('click', () => sendMessage('topics'));
        elements.btnHelp.addEventListener('click', () => sendMessage('help'));
        elements.btnClear.addEventListener('click', clearChat);

        // Close sidebar on outside click (mobile)
        document.addEventListener('click', function (e) {
            if (state.sidebarOpen && !elements.sidebar.contains(e.target) &&
                !elements.menuToggle.contains(e.target)) {
                closeSidebar();
            }
        });
    }

    // --- Input Handlers ---
    function handleInputChange() {
        const hasValue = elements.messageInput.value.trim().length > 0;
        elements.sendBtn.disabled = !hasValue;
        autoResizeTextarea();
    }

    function handleKeyDown(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    }

    function autoResizeTextarea() {
        const textarea = elements.messageInput;
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    // --- Send Message ---
    function handleSend() {
        const text = elements.messageInput.value.trim();
        if (!text || state.isTyping) return;
        sendMessage(text);
    }

    async function sendMessage(text) {
        // Hide welcome screen
        if (elements.welcomeScreen) {
            elements.welcomeScreen.style.display = 'none';
        }

        // Add user message
        addMessage('user', text);

        // Clear input
        elements.messageInput.value = '';
        elements.sendBtn.disabled = true;
        autoResizeTextarea();

        // Show typing indicator
        showTypingIndicator();

        try {
            // Compute typing delay based on text length
            const delay = CONFIG.TYPING_DELAY_MIN +
                Math.random() * (CONFIG.TYPING_DELAY_MAX - CONFIG.TYPING_DELAY_MIN);

            // Send API request
            const responsePromise = fetch(CONFIG.API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text }),
            });

            // Wait for both the delay and the response
            const [response] = await Promise.all([
                responsePromise,
                new Promise(resolve => setTimeout(resolve, delay)),
            ]);

            hideTypingIndicator();

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }

            const data = await response.json();
            addMessage('bot', data.content, data.confidence, data.intent, data.timestamp);
            updateStats(data.confidence);

        } catch (error) {
            hideTypingIndicator();
            console.error('Chat error:', error);
            addMessage('bot',
                'Sorry, I encountered a connection issue. 😔 Please make sure the server is running on port 8080 and try again.',
                0, 'error'
            );
            setStatus(false);
        }

        elements.messageInput.focus();
    }

    // --- Message Rendering ---
    function addMessage(sender, content, confidence, intent, timestamp) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', sender);

        const avatarText = sender === 'bot' ? '🤖' : '👤';

        // Format content: bold text between ** markers
        const formattedContent = formatContent(content);

        const time = timestamp || new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });

        let metaHtml = `<span class="message-time">${time}</span>`;

        if (sender === 'bot' && confidence !== undefined && confidence > 0) {
            const level = confidence >= 0.7 ? 'high' : confidence >= 0.4 ? 'medium' : 'low';
            const pct = Math.round(confidence * 100);
            metaHtml += `<span class="message-confidence ${level}">${pct}% match</span>`;
        }

        messageDiv.innerHTML = `
            <div class="message-avatar">${avatarText}</div>
            <div class="message-content">
                <div class="message-bubble">${formattedContent}</div>
                <div class="message-meta">${metaHtml}</div>
            </div>
        `;

        elements.messagesScroll.appendChild(messageDiv);
        scrollToBottom();

        state.messageCount++;
        elements.statMessages.textContent = state.messageCount;
    }

    function formatContent(text) {
        if (!text) return '';

        // Escape HTML
        let escaped = text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');

        // Convert **bold** markers
        escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

        // Convert newlines to <br>
        escaped = escaped.replace(/\n/g, '<br>');

        return escaped;
    }

    // --- Typing Indicator ---
    function showTypingIndicator() {
        state.isTyping = true;

        const typing = document.createElement('div');
        typing.classList.add('typing-indicator');
        typing.id = 'typing-indicator';
        typing.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="typing-bubble">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;

        elements.messagesScroll.appendChild(typing);
        scrollToBottom();
    }

    function hideTypingIndicator() {
        state.isTyping = false;
        const indicator = document.getElementById('typing-indicator');
        if (indicator) indicator.remove();
    }

    // --- Stats ---
    function updateStats(confidence) {
        if (confidence !== undefined && confidence > 0) {
            state.totalConfidence += confidence;
            state.botResponses++;
            const avg = (state.totalConfidence / state.botResponses * 100).toFixed(0);
            elements.statConfidence.textContent = avg + '%';
        }
    }

    // --- Server Status ---
    async function checkServerStatus() {
        try {
            const response = await fetch('/api/health', { method: 'GET' });
            if (response.ok) {
                setStatus(true);
            } else {
                setStatus(false);
            }
        } catch {
            setStatus(false);
        }
    }

    function setStatus(online) {
        const dot = elements.statusDot;
        const text = elements.statusText;
        if (online) {
            dot.className = 'status-dot online';
            text.textContent = 'Online';
        } else {
            dot.className = 'status-dot offline';
            text.textContent = 'Offline';
        }
    }

    // --- Sidebar ---
    function toggleSidebar() {
        if (state.sidebarOpen) {
            closeSidebar();
        } else {
            openSidebar();
        }
    }

    function openSidebar() {
        elements.sidebar.classList.add('open');
        state.sidebarOpen = true;

        // Create overlay
        let overlay = document.querySelector('.sidebar-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.classList.add('sidebar-overlay');
            overlay.addEventListener('click', closeSidebar);
            document.body.appendChild(overlay);
        }
        overlay.classList.add('active');
    }

    function closeSidebar() {
        elements.sidebar.classList.remove('open');
        state.sidebarOpen = false;

        const overlay = document.querySelector('.sidebar-overlay');
        if (overlay) overlay.classList.remove('active');
    }

    // --- Clear Chat ---
    function clearChat() {
        // Remove all messages and typing indicators
        const messages = elements.messagesScroll.querySelectorAll('.message, .typing-indicator');
        messages.forEach(msg => msg.remove());

        // Show welcome screen again
        if (elements.welcomeScreen) {
            elements.welcomeScreen.style.display = 'flex';
        }

        // Reset stats
        state.messageCount = 0;
        state.totalConfidence = 0;
        state.botResponses = 0;
        elements.statMessages.textContent = '0';
        elements.statConfidence.textContent = '—';

        closeSidebar();
        elements.messageInput.focus();
    }

    // --- Scroll ---
    function scrollToBottom() {
        requestAnimationFrame(() => {
            elements.messagesScroll.scrollTop = elements.messagesScroll.scrollHeight;
        });
    }

    // --- Boot ---
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
