# SecureVision AI Chatbot 🤖

A fully-featured AI chatbot built with **pure Java** — no external dependencies. Features a custom NLP pipeline, hybrid intent matching engine, and a premium web interface.

## ✨ Features

- **Natural Language Processing Pipeline**
  - Tokenization with contraction expansion
  - Stop word removal (175+ English stop words)
  - Porter Stemming Algorithm
  - TF-IDF (Term Frequency–Inverse Document Frequency) vectorization

- **Hybrid Intent Matching**
  - Rule-based engine (regex patterns) for common intents
  - ML-style cosine similarity for FAQ matching
  - Confidence scoring with fallback responses

- **50+ Trainable FAQ Entries** across categories:
  - Artificial Intelligence & Machine Learning
  - Natural Language Processing
  - Programming (Java, Python, OOP, APIs)
  - Web Development & Cloud Computing
  - Cybersecurity & Data Science
  - Technical Support & Fun conversations

- **Premium Web Interface**
  - Dark glassmorphism design
  - Animated chat bubbles with typing indicators
  - Responsive layout (mobile-friendly)
  - Quick action buttons
  - Real-time statistics sidebar

## 🚀 Quick Start

### Prerequisites
- **Java JDK 11+** installed
- `javac` and `java` available on your PATH

### Run (Windows)
```bash
# Double-click or run from command line:
compile_and_run.bat
```

### Run (Manual)
```bash
# 1. Compile
mkdir out
javac -d out -sourcepath src/main/java src/main/java/com/securevision/chatbot/ChatbotServer.java

# 2. Copy resources
xcopy /s /e /i src/resources out/resources

# 3. Run
cd out
java com.securevision.chatbot.ChatbotServer
```

### Access
Open your browser and navigate to:
```
http://localhost:8080
```

## 📁 Project Structure

```
├── src/
│   ├── main/java/com/securevision/chatbot/
│   │   ├── ChatbotServer.java       ← Entry point + HTTP server
│   │   ├── nlp/
│   │   │   ├── NLPProcessor.java    ← Pipeline orchestrator
│   │   │   ├── Tokenizer.java       ← Text tokenization
│   │   │   ├── StopWordRemover.java ← Stop word filtering
│   │   │   ├── PorterStemmer.java   ← Word stemming
│   │   │   └── TFIDFVectorizer.java ← TF-IDF scoring
│   │   ├── engine/
│   │   │   ├── IntentMatcher.java   ← Hybrid intent matching
│   │   │   ├── RuleEngine.java      ← Regex-based rules
│   │   │   └── SimilarityEngine.java← Cosine similarity
│   │   └── model/
│   │       ├── ChatMessage.java     ← Message model
│   │       ├── Intent.java          ← Intent model
│   │       └── KnowledgeBase.java   ← FAQ loader
│   └── resources/
│       ├── knowledge_base.json      ← FAQ training data
│       └── web/
│           ├── index.html           ← Chat UI
│           ├── styles.css           ← Premium styling
│           └── app.js               ← Frontend logic
├── compile_and_run.bat              ← One-click build & run
└── README.md                        ← This file
```

## 🔧 API Reference

### POST `/api/chat`
Send a message to the chatbot.

**Request:**
```json
{
    "message": "What is artificial intelligence?"
}
```

**Response:**
```json
{
    "sender": "bot",
    "content": "Artificial Intelligence (AI) is the simulation of human intelligence...",
    "timestamp": "14:30",
    "confidence": 0.87,
    "intent": "what_is_ai"
}
```

### GET `/api/health`
Check server status.

**Response:**
```json
{
    "status": "healthy",
    "engine": "trained",
    "version": "1.0.0"
}
```

## 🧠 How It Works

```
User Input → Tokenization → Stop Word Removal → Stemming → TF-IDF Vector
                                                                ↓
                                              Cosine Similarity Matching
                                                                ↓
                                    Rule Engine (Regex) ←→ Best Match Selection
                                                                ↓
                                                          Bot Response
```

1. **Tokenization**: Splits text into words, expands contractions, normalizes case
2. **Stop Word Removal**: Filters out common words (the, is, a, etc.)
3. **Stemming**: Reduces words to root form using the Porter algorithm
4. **TF-IDF Vectorization**: Converts text to numerical vectors
5. **Intent Matching**: Hybrid approach — checks rules first, then ML similarity
6. **Response Selection**: Returns the best response with confidence score

## 📝 Customizing the Knowledge Base

Edit `src/resources/knowledge_base.json` to add your own FAQs:

```json
{
    "tag": "your_topic",
    "category": "Your Category",
    "training_phrases": [
        "question variant 1",
        "question variant 2",
        "question variant 3"
    ],
    "responses": [
        "Response option 1",
        "Response option 2"
    ]
}
```

More training phrases = better matching accuracy!

## 📄 License

This project is open source and available for educational purposes.

---

Built with ❤️ using pure Java — no external dependencies required.
