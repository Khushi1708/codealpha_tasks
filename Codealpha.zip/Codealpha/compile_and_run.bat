@echo off
REM ============================================
REM  SecureVision AI Chatbot — Build & Run Script
REM  Compiles all Java sources and starts the server
REM ============================================

echo.
echo  ===================================================
echo   SecureVision AI Chatbot - Build and Run
echo  ===================================================
echo.

REM Set variables
set SRC_DIR=src\main\java
set OUT_DIR=out
set RESOURCES=src\resources
set MAIN_CLASS=com.securevision.chatbot.ChatbotServer

REM Clean previous build
echo [1/4] Cleaning previous build...
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

REM Compile all Java files
echo [2/4] Compiling Java sources...
dir /s /b %SRC_DIR%\*.java > sources.txt
javac -d "%OUT_DIR%" -sourcepath "%SRC_DIR%" @sources.txt
if errorlevel 1 (
    echo.
    echo  ❌ BUILD FAILED! Check the errors above.
    echo  Make sure you have JDK 11+ installed and 'javac' is on your PATH.
    echo.
    del sources.txt
    pause
    exit /b 1
)
del sources.txt
echo     ✅ Compilation successful!

REM Copy resources
echo [3/4] Copying resources...
xcopy /s /e /i /q /y "%RESOURCES%" "%OUT_DIR%\resources" >nul 2>&1
echo     ✅ Resources copied!

REM Run the server
echo [4/4] Starting server...
echo.
cd "%OUT_DIR%"
java -cp . %MAIN_CLASS%

REM If server exits
echo.
echo Server stopped.
pause
