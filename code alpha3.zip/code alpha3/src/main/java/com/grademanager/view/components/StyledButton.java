package com.grademanager.view.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * A highly styled modern button with rounded corners, hover transitions, and flat designs.
 */
public class StyledButton extends JButton {
    public enum ButtonType {
        PRIMARY, SECONDARY, DANGER, SUCCESS
    }

    private final ButtonType type;
    private boolean isHovered = false;
    private int cornerRadius = 12;

    private static final Color COLOR_PRIMARY = new Color(99, 102, 241);    // Indigo
    private static final Color COLOR_PRIMARY_HOVER = new Color(79, 70, 229);
    private static final Color COLOR_SECONDARY = new Color(45, 45, 57);     // Slate
    private static final Color COLOR_SECONDARY_HOVER = new Color(55, 55, 70);
    private static final Color COLOR_DANGER = new Color(239, 68, 68);       // Red
    private static final Color COLOR_DANGER_HOVER = new Color(220, 38, 38);
    private static final Color COLOR_SUCCESS = new Color(16, 185, 129);     // Emerald
    private static final Color COLOR_SUCCESS_HOVER = new Color(5, 150, 105);

    public StyledButton(String text) {
        this(text, ButtonType.PRIMARY);
    }

    public StyledButton(String text, ButtonType type) {
        super(text);
        this.type = type;
        setFocusPainted(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setOpaque(false);
        setFont(new Font("Segoe UI", Font.BOLD, 14));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Configure colors based on type
        switch (type) {
            case PRIMARY:
                setForeground(Color.WHITE);
                break;
            case SECONDARY:
                setForeground(new Color(229, 231, 235)); // Gray-200
                break;
            case DANGER:
                setForeground(Color.WHITE);
                break;
            case SUCCESS:
                setForeground(Color.WHITE);
                break;
        }

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    isHovered = true;
                    repaint();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }
        });
    }

    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Color bgColor;
        if (!isEnabled()) {
            bgColor = new Color(45, 45, 50, 100);
            g2.setColor(bgColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);
            setForeground(new Color(156, 163, 175, 120));
        } else {
            // Pick normal vs hover color
            switch (type) {
                case PRIMARY:
                    bgColor = isHovered ? COLOR_PRIMARY_HOVER : COLOR_PRIMARY;
                    break;
                case DANGER:
                    bgColor = isHovered ? COLOR_DANGER_HOVER : COLOR_DANGER;
                    break;
                case SUCCESS:
                    bgColor = isHovered ? COLOR_SUCCESS_HOVER : COLOR_SUCCESS;
                    break;
                case SECONDARY:
                default:
                    bgColor = isHovered ? COLOR_SECONDARY_HOVER : COLOR_SECONDARY;
                    break;
            }

            g2.setColor(bgColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);
            
            // Re-apply original foreground if enabled
            switch (type) {
                case PRIMARY:
                case DANGER:
                case SUCCESS:
                    setForeground(Color.WHITE);
                    break;
                case SECONDARY:
                    setForeground(new Color(229, 231, 235));
                    break;
            }
        }

        g2.dispose();
        super.paintComponent(g);
    }
}
