package com.grademanager.view.components;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import java.awt.*;

/**
 * A customized flat JTable matching a modern dark-mode application theme.
 */
public class StyledTable extends JTable {
    private static final Color BG_DARK = new Color(22, 22, 26);          // Deep dark
    private static final Color BG_CARD = new Color(30, 30, 36);          // Card base
    private static final Color ROW_ALT = new Color(38, 38, 46);          // Alt row
    private static final Color ACCENT = new Color(99, 102, 241);         // Selection
    private static final Color TEXT_LIGHT = new Color(243, 244, 246);    // White text
    private static final Color TEXT_MUTED = new Color(156, 163, 175);    // Muted grey text
    private static final Color GRID_COLOR = new Color(45, 45, 57);       // Border color

    public StyledTable(TableModel model) {
        super(model);
        setupTable();
    }

    private void setupTable() {
        setOpaque(true);
        setBackground(BG_CARD);
        setForeground(TEXT_LIGHT);
        setGridColor(GRID_COLOR);
        setRowHeight(36);
        setSelectionBackground(ACCENT);
        setSelectionForeground(TEXT_LIGHT);
        setFont(new Font("Segoe UI", Font.PLAIN, 14));
        setShowVerticalLines(false);
        setShowHorizontalLines(true);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setIntercellSpacing(new Dimension(0, 1));

        // Style the table header
        JTableHeader header = getTableHeader();
        header.setOpaque(false);
        header.setBackground(BG_DARK);
        header.setForeground(TEXT_MUTED);
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setPreferredSize(new Dimension(header.getWidth(), 38));
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, GRID_COLOR));

        // Custom default cell renderer
        setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                // Remove standard cell borders
                setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));

                if (isSelected) {
                    setBackground(ACCENT);
                    setForeground(TEXT_LIGHT);
                } else {
                    setBackground(row % 2 == 0 ? BG_CARD : ROW_ALT);
                    setForeground(TEXT_LIGHT);
                }

                // If column is ID, center it, if Grade, right align it
                if (column == 0) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else if (column == 2) {
                    setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }

                return this;
            }
        });

        // Set header alignment and borders
        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(SwingConstants.LEFT);
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setBackground(BG_DARK);
                setForeground(TEXT_MUTED);
                setFont(new Font("Segoe UI", Font.BOLD, 13));
                setBorder(BorderFactory.createEmptyBorder(4, 14, 4, 14));
                
                if (column == 0) {
                    setHorizontalAlignment(SwingConstants.CENTER);
                } else if (column == 2) {
                    setHorizontalAlignment(SwingConstants.RIGHT);
                } else {
                    setHorizontalAlignment(SwingConstants.LEFT);
                }
                return this;
            }
        });
    }

    public static JScrollPane createScrollPane(JTable table) {
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(GRID_COLOR, 1, true));
        scrollPane.getViewport().setBackground(BG_CARD);
        
        // Style scrollbars minimally
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 8));
        scrollPane.getVerticalScrollBar().setBackground(BG_DARK);
        scrollPane.getVerticalScrollBar().setUnitIncrement(12);

        return scrollPane;
    }
}
