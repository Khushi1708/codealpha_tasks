package com.grademanager.view;

import com.grademanager.model.Student;
import com.grademanager.service.GradeService;
import com.grademanager.view.components.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Main dashboard user interface for the Grade Manager application.
 */
public class GradeManagerGUI extends JFrame {
    private final GradeService gradeService;
    
    // Core Swing UI Components
    private DefaultTableModel tableModel;
    private StyledTable studentTable;
    private TableRowSorter<DefaultTableModel> rowSorter;
    
    private StyledTextField txtId;
    private StyledTextField txtName;
    private StyledTextField txtScore;
    private StyledTextField txtSearch;
    
    // Metric Labels
    private JLabel lblAverage;
    private JLabel lblHighest;
    private JLabel lblHighestStudent;
    private JLabel lblLowest;
    private JLabel lblLowestStudent;
    private JLabel lblTotalCount;
    
    // Chart Component
    private GradeChart gradeChart;

    // Design Colors
    private static final Color BG_DARK = new Color(18, 18, 20);           // #121214
    private static final Color BG_CARD = new Color(30, 30, 36);           // #1e1e24
    private static final Color TEXT_LIGHT = new Color(243, 244, 246);     // #f3f4f6
    private static final Color TEXT_MUTED = new Color(156, 163, 175);     // #9ca3af
    private static final Color ACCENT_COLOR = new Color(99, 102, 241);    // Indigo

    public GradeManagerGUI(GradeService gradeService) {
        this.gradeService = gradeService;
        
        setTitle("Student Grade Analytics Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 700));
        setSize(1150, 750);
        setLocationRelativeTo(null);
        
        // Root Panel Configuration
        JPanel rootPanel = new JPanel(new BorderLayout(16, 16));
        rootPanel.setBackground(BG_DARK);
        rootPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        setContentPane(rootPanel);

        // Header Panel (App Title + Action Buttons)
        rootPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Dashboard Center Body (Metrics + Workspace grid)
        JPanel mainWorkspace = new JPanel(new BorderLayout(16, 16));
        mainWorkspace.setOpaque(false);
        
        mainWorkspace.add(createMetricsGrid(), BorderLayout.NORTH);
        mainWorkspace.add(createWorkspaceSplit(), BorderLayout.CENTER);
        
        rootPanel.add(mainWorkspace, BorderLayout.CENTER);
        
        // Initial Data Load (Mock Data)
        gradeService.loadMockData();
        refreshUI();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        // Left: Title and Subtitle
        JPanel titleGroup = new JPanel(new GridLayout(2, 1, 2, 2));
        titleGroup.setOpaque(false);
        
        JLabel titleLabel = new JLabel("Academic Performance Analytics");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(TEXT_LIGHT);
        
        JLabel subtitleLabel = new JLabel("Monitor, manage, and analyze student grade distributions.");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitleLabel.setForeground(TEXT_MUTED);
        
        titleGroup.add(titleLabel);
        titleGroup.add(subtitleLabel);
        headerPanel.add(titleGroup, BorderLayout.WEST);

        // Right: Core Import/Export Actions
        JPanel actionsGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionsGroup.setOpaque(false);

        StyledButton btnImport = new StyledButton("Import CSV", StyledButton.ButtonType.SECONDARY);
        btnImport.setPreferredSize(new Dimension(120, 36));
        btnImport.addActionListener(e -> handleImportCSV());

        StyledButton btnExport = new StyledButton("Export CSV", StyledButton.ButtonType.SECONDARY);
        btnExport.setPreferredSize(new Dimension(120, 36));
        btnExport.addActionListener(e -> handleExportCSV());

        StyledButton btnMock = new StyledButton("Reset Mock Data", StyledButton.ButtonType.SECONDARY);
        btnMock.setPreferredSize(new Dimension(140, 36));
        btnMock.addActionListener(e -> {
            gradeService.loadMockData();
            refreshUI();
            JOptionPane.showMessageDialog(this, "Mock student data loaded successfully.", "Data Reset", JOptionPane.INFORMATION_MESSAGE);
        });

        actionsGroup.add(btnMock);
        actionsGroup.add(btnImport);
        actionsGroup.add(btnExport);
        headerPanel.add(actionsGroup, BorderLayout.EAST);

        return headerPanel;
    }

    private JPanel createMetricsGrid() {
        JPanel metricsPanel = new JPanel(new GridLayout(1, 4, 16, 0));
        metricsPanel.setOpaque(false);
        metricsPanel.setPreferredSize(new Dimension(0, 100));

        // 1. Average Score Card
        CardPanel cardAvg = new CardPanel(16);
        cardAvg.setLayout(new BorderLayout());
        cardAvg.setBorder(new EmptyBorder(12, 16, 12, 16));
        
        JLabel titleAvg = new JLabel("AVERAGE GRADE");
        titleAvg.setFont(new Font("Segoe UI", Font.BOLD, 11));
        titleAvg.setForeground(TEXT_MUTED);
        lblAverage = new JLabel("0.0%");
        lblAverage.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblAverage.setForeground(ACCENT_COLOR);
        
        cardAvg.add(titleAvg, BorderLayout.NORTH);
        cardAvg.add(lblAverage, BorderLayout.CENTER);
        metricsPanel.add(cardAvg);

        // 2. Highest Grade Card
        CardPanel cardHigh = new CardPanel(16);
        cardHigh.setLayout(new BorderLayout());
        cardHigh.setBorder(new EmptyBorder(12, 16, 12, 16));
        
        JLabel titleHigh = new JLabel("HIGHEST GRADE");
        titleHigh.setFont(new Font("Segoe UI", Font.BOLD, 11));
        titleHigh.setForeground(TEXT_MUTED);
        
        JPanel highContent = new JPanel(new GridLayout(2, 1, 0, 0));
        highContent.setOpaque(false);
        lblHighest = new JLabel("0.0");
        lblHighest.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblHighest.setForeground(new Color(16, 185, 129)); // Success green
        lblHighestStudent = new JLabel("N/A");
        lblHighestStudent.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblHighestStudent.setForeground(TEXT_MUTED);
        highContent.add(lblHighest);
        highContent.add(lblHighestStudent);
        
        cardHigh.add(titleHigh, BorderLayout.NORTH);
        cardHigh.add(highContent, BorderLayout.CENTER);
        metricsPanel.add(cardHigh);

        // 3. Lowest Grade Card
        CardPanel cardLow = new CardPanel(16);
        cardLow.setLayout(new BorderLayout());
        cardLow.setBorder(new EmptyBorder(12, 16, 12, 16));
        
        JLabel titleLow = new JLabel("LOWEST GRADE");
        titleLow.setFont(new Font("Segoe UI", Font.BOLD, 11));
        titleLow.setForeground(TEXT_MUTED);
        
        JPanel lowContent = new JPanel(new GridLayout(2, 1, 0, 0));
        lowContent.setOpaque(false);
        lblLowest = new JLabel("0.0");
        lblLowest.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblLowest.setForeground(new Color(239, 68, 68)); // Danger red
        lblLowestStudent = new JLabel("N/A");
        lblLowestStudent.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblLowestStudent.setForeground(TEXT_MUTED);
        lowContent.add(lblLowest);
        lowContent.add(lblLowestStudent);
        
        cardLow.add(titleLow, BorderLayout.NORTH);
        cardLow.add(lowContent, BorderLayout.CENTER);
        metricsPanel.add(cardLow);

        // 4. Total Count Card
        CardPanel cardCount = new CardPanel(16);
        cardCount.setLayout(new BorderLayout());
        cardCount.setBorder(new EmptyBorder(12, 16, 12, 16));
        
        JLabel titleCount = new JLabel("TOTAL STUDENTS");
        titleCount.setFont(new Font("Segoe UI", Font.BOLD, 11));
        titleCount.setForeground(TEXT_MUTED);
        lblTotalCount = new JLabel("0");
        lblTotalCount.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTotalCount.setForeground(TEXT_LIGHT);
        
        cardCount.add(titleCount, BorderLayout.NORTH);
        cardCount.add(lblTotalCount, BorderLayout.CENTER);
        metricsPanel.add(cardCount);

        return metricsPanel;
    }

    private JPanel createWorkspaceSplit() {
        JPanel workspace = new JPanel(new BorderLayout(16, 16));
        workspace.setOpaque(false);

        // West side: Manage Grade Input Form Card
        workspace.add(createFormPanel(), BorderLayout.WEST);

        // Center side: Grades Table Card
        workspace.add(createTableCard(), BorderLayout.CENTER);

        // East side: Analytics Chart Card
        workspace.add(createChartCard(), BorderLayout.EAST);

        return workspace;
    }

    private JPanel createFormPanel() {
        CardPanel formCard = new CardPanel(16);
        formCard.setPreferredSize(new Dimension(300, 0));
        formCard.setBorder(new EmptyBorder(20, 20, 20, 20));
        formCard.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Card Header
        JLabel formTitle = new JLabel("Manage Student");
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        formTitle.setForeground(TEXT_LIGHT);
        formCard.add(formTitle, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(4, 0, 20, 0);
        JLabel formSub = new JLabel("Add or update record details");
        formSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        formSub.setForeground(TEXT_MUTED);
        formCard.add(formSub, gbc);

        // Input 1: Student ID
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 6, 0);
        JLabel lblId = new JLabel("STUDENT ID");
        lblId.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblId.setForeground(TEXT_MUTED);
        formCard.add(lblId, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 16, 0);
        txtId = new StyledTextField("e.g. S109");
        formCard.add(txtId, gbc);

        // Input 2: Student Name
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 6, 0);
        JLabel lblName = new JLabel("FULL NAME");
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblName.setForeground(TEXT_MUTED);
        formCard.add(lblName, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 16, 0);
        txtName = new StyledTextField("e.g. John Doe");
        formCard.add(txtName, gbc);

        // Input 3: Score Grade
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 6, 0);
        JLabel lblScore = new JLabel("GRADE / SCORE (0 - 100)");
        lblScore.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblScore.setForeground(TEXT_MUTED);
        formCard.add(lblScore, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 24, 0);
        txtScore = new StyledTextField("e.g. 88.5");
        formCard.add(txtScore, gbc);

        // Actions Group Panel
        gbc.gridy++;
        gbc.weighty = 0.0;
        gbc.insets = new Insets(0, 0, 12, 0);
        StyledButton btnSave = new StyledButton("Save Student", StyledButton.ButtonType.PRIMARY);
        btnSave.setPreferredSize(new Dimension(0, 40));
        btnSave.addActionListener(e -> handleSaveStudent());
        formCard.add(btnSave, gbc);

        gbc.gridy++;
        StyledButton btnDelete = new StyledButton("Delete Selected", StyledButton.ButtonType.DANGER);
        btnDelete.setPreferredSize(new Dimension(0, 40));
        btnDelete.addActionListener(e -> handleDeleteStudent());
        formCard.add(btnDelete, gbc);

        // Filler space to push everything to the top
        gbc.gridy++;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        JPanel filler = new JPanel();
        filler.setOpaque(false);
        formCard.add(filler, gbc);

        // Clear All at the bottom
        gbc.gridy++;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(12, 0, 0, 0);
        StyledButton btnClear = new StyledButton("Clear All Records", StyledButton.ButtonType.SECONDARY);
        btnClear.setPreferredSize(new Dimension(0, 36));
        btnClear.addActionListener(e -> handleClearAll());
        formCard.add(btnClear, gbc);

        return formCard;
    }

    private JPanel createTableCard() {
        CardPanel tableCard = new CardPanel(16);
        tableCard.setBorder(new EmptyBorder(20, 20, 20, 20));
        tableCard.setLayout(new BorderLayout(0, 12));

        // Top of Table Card: Search & Header Label
        JPanel searchBarPanel = new JPanel(new BorderLayout(12, 0));
        searchBarPanel.setOpaque(false);

        JLabel tableTitle = new JLabel("Students List");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        tableTitle.setForeground(TEXT_LIGHT);
        searchBarPanel.add(tableTitle, BorderLayout.WEST);

        txtSearch = new StyledTextField("Search student name or ID...");
        txtSearch.setPreferredSize(new Dimension(220, 36));
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            @Override
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            @Override
            public void changedUpdate(DocumentEvent e) { filterTable(); }
        });
        searchBarPanel.add(txtSearch, BorderLayout.EAST);

        tableCard.add(searchBarPanel, BorderLayout.NORTH);

        // Table Setup
        String[] columns = {"Student ID", "Student Name", "Grade"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // read-only list interface
            }
        };

        studentTable = new StyledTable(tableModel);
        rowSorter = new TableRowSorter<>(tableModel);
        studentTable.setRowSorter(rowSorter);

        // Table Row Selection Listener (populate details on click)
        studentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = studentTable.getSelectedRow();
                if (selectedRow != -1) {
                    // convert row index in case table is filtered/sorted
                    int modelRow = studentTable.convertRowIndexToModel(selectedRow);
                    txtId.setText((String) tableModel.getValueAt(modelRow, 0));
                    txtId.setEnabled(false); // ID is read-only when updating existing record
                    txtName.setText((String) tableModel.getValueAt(modelRow, 1));
                    txtScore.setText(String.valueOf(tableModel.getValueAt(modelRow, 2)));
                } else {
                    resetForm();
                }
            }
        });

        JScrollPane scrollPane = StyledTable.createScrollPane(studentTable);
        tableCard.add(scrollPane, BorderLayout.CENTER);

        return tableCard;
    }

    private JPanel createChartCard() {
        CardPanel chartCard = new CardPanel(16);
        chartCard.setPreferredSize(new Dimension(350, 0));
        chartCard.setBorder(new EmptyBorder(10, 10, 10, 10));
        chartCard.setLayout(new BorderLayout());

        gradeChart = new GradeChart();
        chartCard.add(gradeChart, BorderLayout.CENTER);

        return chartCard;
    }

    // --- UI Actions & Logic ---

    private void filterTable() {
        String filterText = txtSearch.getText().trim();
        if (filterText.equals("Search student name or ID...") || filterText.isEmpty()) {
            rowSorter.setRowFilter(null);
        } else {
            rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + filterText));
        }
    }

    private void handleSaveStudent() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String scoreStr = txtScore.getText().trim();

        if (id.isEmpty() || id.equals("e.g. S109")) {
            showError("Student ID is required.");
            return;
        }
        if (name.isEmpty() || name.equals("e.g. John Doe")) {
            showError("Student Name is required.");
            return;
        }
        
        double score;
        try {
            score = Double.parseDouble(scoreStr);
        } catch (NumberFormatException e) {
            showError("Grade must be a valid decimal number.");
            return;
        }

        try {
            // Check if existing ID is being updated (txtId disabled means updating)
            if (!txtId.isEnabled()) {
                gradeService.updateStudent(id, name, score);
            } else {
                // Check if the user is typing an existing ID in a fresh field
                boolean exists = false;
                for (Student s : gradeService.getStudents()) {
                    if (s.getId().equalsIgnoreCase(id)) {
                        exists = true;
                        break;
                    }
                }

                if (exists) {
                    int response = JOptionPane.showConfirmDialog(this,
                            "A student with ID '" + id + "' already exists.\nDo you want to update their details instead?",
                            "Update Existing Student",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE);
                    if (response == JOptionPane.YES_OPTION) {
                        gradeService.updateStudent(id, name, score);
                    } else {
                        return;
                    }
                } else {
                    gradeService.addStudent(new Student(id, name, score));
                }
            }
            refreshUI();
            resetForm();
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleDeleteStudent() {
        int selectedRow = studentTable.getSelectedRow();
        String idToDelete = null;

        if (selectedRow != -1) {
            int modelRow = studentTable.convertRowIndexToModel(selectedRow);
            idToDelete = (String) tableModel.getValueAt(modelRow, 0);
        } else {
            // Fallback: check if the text field has a value
            String idVal = txtId.getText().trim();
            if (!idVal.isEmpty() && !idVal.equals("e.g. S109") && !txtId.isEnabled()) {
                idToDelete = idVal;
            }
        }

        if (idToDelete == null) {
            showError("Please select a student from the list to delete.");
            return;
        }

        int response = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to remove the student with ID: " + idToDelete + "?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            gradeService.removeStudent(idToDelete);
            refreshUI();
            resetForm();
        }
    }

    private void handleClearAll() {
        if (gradeService.getStudentCount() == 0) {
            showError("No records to clear.");
            return;
        }

        int response = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete ALL student records?\nThis action cannot be undone.",
                "Confirm Clear All",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            gradeService.clearAll();
            refreshUI();
            resetForm();
        }
    }

    private void handleImportCSV() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Import Student Grades from CSV");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));
        
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                gradeService.importFromCSV(selectedFile);
                refreshUI();
                resetForm();
                JOptionPane.showMessageDialog(this, "Grades imported successfully.", "Import Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                showError("Import Failed: " + e.getMessage());
            }
        }
    }

    private void handleExportCSV() {
        if (gradeService.getStudentCount() == 0) {
            showError("No student records available to export.");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Student Grades to CSV");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));
        fileChooser.setSelectedFile(new File("student_grades.csv"));
        
        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            // Append extension if missing
            if (!selectedFile.getName().toLowerCase().endsWith(".csv")) {
                selectedFile = new File(selectedFile.getAbsolutePath() + ".csv");
            }
            try {
                gradeService.exportToCSV(selectedFile);
                JOptionPane.showMessageDialog(this, "Grades exported successfully to:\n" + selectedFile.getAbsolutePath(), "Export Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                showError("Export Failed: " + e.getMessage());
            }
        }
    }

    private void refreshUI() {
        // 1. Refresh Table Model
        tableModel.setRowCount(0);
        List<Student> students = gradeService.getStudents();
        for (Student s : students) {
            tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getScore()});
        }

        // 2. Refresh Metric Cards
        int count = gradeService.getStudentCount();
        lblTotalCount.setText(String.valueOf(count));
        
        if (count > 0) {
            lblAverage.setText(String.format("%.2f%%", gradeService.calculateAverage()));
            
            Student highest = gradeService.getHighestScoreStudent();
            lblHighest.setText(String.format("%.2f", highest.getScore()));
            lblHighestStudent.setText("by " + highest.getName());
            
            Student lowest = gradeService.getLowestScoreStudent();
            lblLowest.setText(String.format("%.2f", lowest.getScore()));
            lblLowestStudent.setText("by " + lowest.getName());
        } else {
            lblAverage.setText("0.00%");
            lblHighest.setText("0.0");
            lblHighestStudent.setText("N/A");
            lblLowest.setText("0.0");
            lblLowestStudent.setText("N/A");
        }

        // 3. Refresh Custom Chart
        Map<String, Integer> distribution = gradeService.getGradeDistribution();
        gradeChart.setDistribution(distribution);
    }

    private void resetForm() {
        txtId.setText("");
        txtId.setEnabled(true);
        txtName.setText("");
        txtScore.setText("");
        studentTable.clearSelection();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation Error", JOptionPane.ERROR_MESSAGE);
    }
}
