package com.grademanager.view.components;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/**
 * A sleek modern text field with rounded corners, custom padding, placeholder text, and focus highlight.
 */
public class StyledTextField extends JTextField {
    private final String placeholder;
    private boolean isFocused = false;
    private int cornerRadius = 12;

    private static final Color BG_COLOR = new Color(22, 22, 26);         // Dark input field background
    private static final Color BORDER_COLOR = new Color(45, 45, 57);     // Normal border
    private static final Color FOCUS_COLOR = new Color(99, 102, 241);    // Focus border (Indigo)
    private static final Color TEXT_COLOR = new Color(243, 244, 246);    // Main text
    private static final Color PLACEHOLDER_COLOR = new Color(107, 114, 128); // Grey hint text

    public StyledTextField(String placeholder) {
        this.placeholder = placeholder;
        setOpaque(false);
        setForeground(TEXT_COLOR);
        setCaretColor(TEXT_COLOR);
        setFont(new Font("Segoe UI", Font.PLAIN, 14));
        setBorder(new EmptyBorder(10, 14, 10, 14)); // Custom inner margins

        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                isFocused = true;
                repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                isFocused = false;
                repaint();
            }
        });
    }

    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Fill background
        g2.setColor(BG_COLOR);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius);

        // Draw border
        g2.setColor(isFocused ? FOCUS_COLOR : BORDER_COLOR);
        g2.setStroke(new BasicStroke(isFocused ? 2.0f : 1.2f));
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius);

        g2.dispose();
        super.paintComponent(g);

        // Paint placeholder text if empty and not focused
        if ((getText() == null || getText().isEmpty()) && !isFocused) {
            Graphics2D gPlaceholder = (Graphics2D) g.create();
            gPlaceholder.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            gPlaceholder.setColor(PLACEHOLDER_COLOR);
            gPlaceholder.setFont(getFont().deriveFont(Font.ITALIC));
            
            // Calculate baseline position
            FontMetrics fm = gPlaceholder.getFontMetrics();
            int x = getInsets().left;
            int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            gPlaceholder.drawString(placeholder, x, y);
            gPlaceholder.dispose();
        }
    }
}
