package com.grademanager.view.components;

import javax.swing.*;
import java.awt.*;

/**
 * A custom Swing panel with rounded corners and modern flat aesthetics.
 */
public class CardPanel extends JPanel {
    private int cornerRadius = 16;
    private Color backgroundColor = new Color(30, 30, 36); // #1e1e24
    private Color borderColor = new Color(45, 45, 57);     // #2d2d39
    private boolean drawBorder = true;

    public CardPanel() {
        setOpaque(false);
    }

    public CardPanel(int cornerRadius) {
        this.cornerRadius = cornerRadius;
        setOpaque(false);
    }

    public CardPanel(int cornerRadius, Color bgColor) {
        this.cornerRadius = cornerRadius;
        this.backgroundColor = bgColor;
        setOpaque(false);
    }

    public void setBackgroundColor(Color color) {
        this.backgroundColor = color;
        repaint();
    }

    public void setBorderColor(Color color) {
        this.borderColor = color;
        repaint();
    }

    public void setDrawBorder(boolean drawBorder) {
        this.drawBorder = drawBorder;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw card background
        g2.setColor(backgroundColor);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius);

        // Draw soft border
        if (drawBorder) {
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, cornerRadius, cornerRadius);
        }

        g2.dispose();
    }
}
