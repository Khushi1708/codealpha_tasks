package com.grademanager.view.components;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A sleek custom component for rendering a bar chart of the grade distribution.
 */
public class GradeChart extends JPanel {
    private Map<String, Integer> data = new LinkedHashMap<>();
    
    private static final Color BG_COLOR = new Color(30, 30, 36);         // Card Background
    private static final Color TEXT_MUTED = new Color(156, 163, 175);    // Slate 400
    private static final Color GRID_COLOR = new Color(45, 45, 57, 120);  // Border transparency
    private static final Color GRADIENT_START = new Color(99, 102, 241); // Indigo 500
    private static final Color GRADIENT_END = new Color(168, 85, 247);   // Purple 500

    public GradeChart() {
        setOpaque(false);
        // Default empty data
        data.put("A", 0);
        data.put("B", 0);
        data.put("C", 0);
        data.put("D", 0);
        data.put("F", 0);
    }

    public void setDistribution(Map<String, Integer> rawData) {
        this.data = new LinkedHashMap<>();
        // Simplify labels for chart mapping: A (90-100) -> A, etc.
        for (Map.Entry<String, Integer> entry : rawData.entrySet()) {
            String key = entry.getKey();
            String shortKey = key.split(" ")[0]; // "A (90-100)" -> "A"
            this.data.put(shortKey, entry.getValue());
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        // Chart margins
        int leftMargin = 35;
        int rightMargin = 20;
        int topMargin = 30;
        int bottomMargin = 35;

        int chartWidth = width - leftMargin - rightMargin;
        int chartHeight = height - topMargin - bottomMargin;

        // Draw title
        g2.setColor(new Color(243, 244, 246));
        g2.setFont(new Font("Segoe UI", Font.BOLD, 14));
        g2.drawString("Grade Distribution", 15, 20);

        if (chartWidth <= 0 || chartHeight <= 0) {
            g2.dispose();
            return;
        }

        // Calculate max value for scaling
        int maxVal = 4; // minimum scale top
        for (int val : data.values()) {
            if (val > maxVal) {
                maxVal = val;
            }
        }
        // Round up to nearest even number to look nice on grids
        if (maxVal % 2 != 0) {
            maxVal += 1;
        }

        // Draw horizontal grid lines and Y-axis values
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        int gridLines = 4;
        for (int i = 0; i <= gridLines; i++) {
            float ratio = (float) i / gridLines;
            int y = topMargin + (int) (chartHeight * (1 - ratio));
            int val = (int) (maxVal * ratio);

            // Grid line
            g2.setColor(GRID_COLOR);
            g2.setStroke(new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{3}, 0));
            g2.drawLine(leftMargin, y, width - rightMargin, y);

            // Label
            g2.setColor(TEXT_MUTED);
            String label = String.valueOf(val);
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(label, leftMargin - fm.stringWidth(label) - 8, y + (fm.getAscent() / 2) - 1);
        }

        // Draw bars and X-axis labels
        int numBars = data.size();
        int gap = 16;
        int totalGaps = (numBars - 1) * gap;
        int barWidth = (chartWidth - totalGaps) / numBars;

        int index = 0;
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            String category = entry.getKey();
            int value = entry.getValue();

            int x = leftMargin + index * (barWidth + gap);
            int barHeight = (int) ((double) value / maxVal * chartHeight);
            int y = topMargin + chartHeight - barHeight;

            // Draw bar with gradient
            if (barHeight > 0) {
                GradientPaint gp = new GradientPaint(
                        x, y, GRADIENT_START,
                        x, y + barHeight, GRADIENT_END
                );
                g2.setPaint(gp);
                // Draw rounded top corners, but sharp bottoms.
                // Swing round rect is fully rounded. To make only top rounded, we can draw a round rect and then cover bottom half with a regular rect,
                // or just draw a neat round rect that spans a bit below the axis or has slightly rounded corners. Let's draw a nice fully rounded rect, or just standard rounded bar.
                int radius = Math.min(10, barWidth / 2);
                if (barHeight > radius) {
                    g2.fillRoundRect(x, y, barWidth, barHeight, radius, radius);
                    // Fill bottom portion to make it square on the bottom
                    g2.fillRect(x, y + barHeight - radius, barWidth, radius);
                } else {
                    g2.fillRoundRect(x, y, barWidth, barHeight, radius, radius);
                }

                // Draw value above bar
                g2.setColor(new Color(243, 244, 246));
                g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
                String valStr = String.valueOf(value);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(valStr, x + (barWidth - fm.stringWidth(valStr)) / 2, y - 6);
            }

            // Draw X-axis label
            g2.setColor(TEXT_MUTED);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            int labelX = x + (barWidth - fm.stringWidth(category)) / 2;
            g2.drawString(category, labelX, height - bottomMargin + fm.getAscent() + 6);

            index++;
        }

        // Draw baseline
        g2.setColor(GRID_COLOR);
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawLine(leftMargin, topMargin + chartHeight, width - rightMargin, topMargin + chartHeight);

        g2.dispose();
    }
}
