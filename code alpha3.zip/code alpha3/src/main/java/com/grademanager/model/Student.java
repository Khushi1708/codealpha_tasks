package com.grademanager.model;

/**
 * Represents a student with a name, unique ID, and a grade score.
 */
public class Student {
    private final String id;
    private String name;
    private double score;

    public Student(String id, String name, double score) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Student ID cannot be empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Student Name cannot be empty.");
        }
        validateScore(score);
        
        this.id = id.trim();
        this.name = name.trim();
        this.score = score;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Student Name cannot be empty.");
        }
        this.name = name.trim();
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        validateScore(score);
        this.score = score;
    }

    private void validateScore(double score) {
        if (score < 0.0 || score > 100.0) {
            throw new IllegalArgumentException("Score must be between 0.0 and 100.0.");
        }
    }

    @Override
    public String toString() {
        return String.format("Student[ID=%s, Name=%s, Score=%.2f]", id, name, score);
    }
}
