package com.grademanager;

import com.grademanager.model.Student;
import com.grademanager.service.GradeService;
import com.grademanager.view.GradeManagerGUI;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Main bootstrap class containing entry points for both GUI and CLI modes.
 */
public class StudentGradeManager {
    private static final GradeService gradeService = new GradeService();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean forceConsole = false;
        
        // Parse flags
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--console") || arg.equalsIgnoreCase("-c")) {
                forceConsole = true;
                break;
            }
        }

        // Run in GUI mode unless console is forced or graphics environment is headless
        if (!forceConsole && !GraphicsEnvironment.isHeadless()) {
            launchGUI();
        } else {
            runConsoleCLI();
        }
    }

    private static void launchGUI() {
        try {
            // Apply System Look and Feel to make standard system dialogues blend in
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Fallback gracefully
        }

        SwingUtilities.invokeLater(() -> {
            GradeManagerGUI gui = new GradeManagerGUI(gradeService);
            gui.setVisible(true);
        });
    }

    private static void runConsoleCLI() {
        System.out.println("=================================================");
        System.out.println("      STUDENT GRADE ANALYTICS SYSTEM - CLI       ");
        System.out.println("=================================================");
        
        // Load initial mock records so CLI isn't empty on boot
        gradeService.loadMockData();
        System.out.println("Loaded default mock student records.");

        boolean running = true;
        while (running) {
            printMainMenu();
            System.out.print("\nSelect an action (1-9): ");
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1":
                    displaySummaryReport();
                    break;
                case "2":
                    handleAddStudent();
                    break;
                case "3":
                    handleUpdateStudent();
                    break;
                case "4":
                    handleDeleteStudent();
                    break;
                case "5":
                    handleImportCSV();
                    break;
                case "6":
                    handleExportCSV();
                    break;
                case "7":
                    handleClearAll();
                    break;
                case "8":
                    gradeService.loadMockData();
                    System.out.println("\n[Success] Mock student records loaded successfully.");
                    break;
                case "9":
                    running = false;
                    System.out.println("\nThank you for using Student Grade Analytics. Goodbye!");
                    break;
                default:
                    System.out.println("\n[Error] Invalid option. Please input a number between 1 and 9.");
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("\n---------------- MAIN MENU ----------------");
        System.out.println("1. View Student Grade Summary Report");
        System.out.println("2. Add New Student Record");
        System.out.println("3. Update Existing Student");
        System.out.println("4. Delete Student Record");
        System.out.println("5. Import Student Grades from CSV");
        System.out.println("6. Export Student Grades to CSV");
        System.out.println("7. Clear All Records");
        System.out.println("8. Reload Default Mock Records");
        System.out.println("9. Exit Application");
    }

    private static void displaySummaryReport() {
        List<Student> list = gradeService.getStudents();
        System.out.println("\n=================================================================================");
        System.out.println("                           STUDENT GRADE SUMMARY REPORT                          ");
        System.out.println("=================================================================================");
        System.out.printf(" %-12s | %-32s | %-12s | %-8s %n", "Student ID", "Student Name", "Grade Score", "Letter");
        System.out.println("--------------+----------------------------------+--------------+-----------------");

        if (list.isEmpty()) {
            System.out.printf(" %-77s %n", "No student records currently stored.");
        } else {
            for (Student s : list) {
                System.out.printf(" %-12s | %-32s | %-12.2f | %-8s %n", 
                        s.getId(), 
                        s.getName(), 
                        s.getScore(), 
                        getLetterGrade(s.getScore()));
            }
        }
        System.out.println("--------------+----------------------------------+--------------+-----------------");
        
        // Print Metrics Summary
        int count = gradeService.getStudentCount();
        System.out.println(" STATISTICS:");
        System.out.printf("  - Total Students: %d %n", count);
        if (count > 0) {
            System.out.printf("  - Average Grade:  %.2f%% %n", gradeService.calculateAverage());
            Student highest = gradeService.getHighestScoreStudent();
            System.out.printf("  - Highest Grade:  %.2f (%s) %n", highest.getScore(), highest.getName());
            Student lowest = gradeService.getLowestScoreStudent();
            System.out.printf("  - Lowest Grade:   %.2f (%s) %n", lowest.getScore(), lowest.getName());
            
            // Print ASCII bar distribution
            System.out.println("\n GRADE DISTRIBUTION:");
            Map<String, Integer> dist = gradeService.getGradeDistribution();
            for (Map.Entry<String, Integer> entry : dist.entrySet()) {
                String label = entry.getKey().split(" ")[0]; // Get letter
                int value = entry.getValue();
                StringBuilder bar = new StringBuilder();
                for (int i = 0; i < value; i++) {
                    bar.append("#");
                }
                System.out.printf("  %-3s : %-15s (%d) %n", label, bar.toString(), value);
            }
        }
        System.out.println("=================================================================================");
    }

    private static String getLetterGrade(double score) {
        if (score >= 90.0) return "A";
        if (score >= 80.0) return "B";
        if (score >= 70.0) return "C";
        if (score >= 60.0) return "D";
        return "F";
    }

    private static void handleAddStudent() {
        System.out.println("\n--- ADD NEW STUDENT ---");
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println("[Error] Student ID cannot be empty.");
            return;
        }

        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("[Error] Student Name cannot be empty.");
            return;
        }

        System.out.print("Enter Student Grade (0-100): ");
        double score;
        try {
            score = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("[Error] Grade must be a valid decimal value.");
            return;
        }

        try {
            Student s = new Student(id, name, score);
            gradeService.addStudent(s);
            System.out.println("[Success] Student record added: " + s);
        } catch (IllegalArgumentException e) {
            System.out.println("[Error] Add failed: " + e.getMessage());
        }
    }

    private static void handleUpdateStudent() {
        System.out.println("\n--- UPDATE EXISTING STUDENT ---");
        System.out.print("Enter ID of the student to update: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println("[Error] Student ID cannot be empty.");
            return;
        }

        // Search for existing student first to display original values
        Student match = null;
        for (Student s : gradeService.getStudents()) {
            if (s.getId().equalsIgnoreCase(id)) {
                match = s;
                break;
            }
        }

        if (match == null) {
            System.out.println("[Error] Student with ID '" + id + "' not found.");
            return;
        }

        System.out.println("Current values: Name = " + match.getName() + ", Grade = " + match.getScore());
        
        System.out.print("Enter New Name (leave blank to keep current): ");
        String nameInput = scanner.nextLine().trim();
        String name = nameInput.isEmpty() ? match.getName() : nameInput;

        System.out.print("Enter New Grade (leave blank to keep current): ");
        String scoreInput = scanner.nextLine().trim();
        double score = match.getScore();
        if (!scoreInput.isEmpty()) {
            try {
                score = Double.parseDouble(scoreInput);
            } catch (NumberFormatException e) {
                System.out.println("[Error] Grade must be a valid decimal value.");
                return;
            }
        }

        try {
            gradeService.updateStudent(id, name, score);
            System.out.println("[Success] Student record updated successfully.");
        } catch (IllegalArgumentException | NoSuchElementException e) {
            System.out.println("[Error] Update failed: " + e.getMessage());
        }
    }

    private static void handleDeleteStudent() {
        System.out.println("\n--- DELETE STUDENT RECORD ---");
        System.out.print("Enter ID of student to remove: ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println("[Error] Student ID cannot be empty.");
            return;
        }

        boolean removed = gradeService.removeStudent(id);
        if (removed) {
            System.out.println("[Success] Student record removed.");
        } else {
            System.out.println("[Error] Student ID '" + id + "' not found.");
        }
    }

    private static void handleImportCSV() {
        System.out.println("\n--- IMPORT GRADES FROM CSV ---");
        System.out.print("Enter path to CSV file: ");
        String path = scanner.nextLine().trim();
        if (path.isEmpty()) {
            System.out.println("[Error] Path cannot be empty.");
            return;
        }

        File file = new File(path);
        if (!file.exists() || !file.isFile()) {
            System.out.println("[Error] File does not exist or is not a valid file.");
            return;
        }

        try {
            gradeService.importFromCSV(file);
            System.out.println("[Success] Grades imported successfully from: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("[Error] Import failed: " + e.getMessage());
        }
    }

    private static void handleExportCSV() {
        System.out.println("\n--- EXPORT GRADES TO CSV ---");
        if (gradeService.getStudentCount() == 0) {
            System.out.println("[Error] No student records available to export.");
            return;
        }

        System.out.print("Enter target path/filename for CSV (e.g. grades.csv): ");
        String path = scanner.nextLine().trim();
        if (path.isEmpty()) {
            System.out.println("[Error] Path cannot be empty.");
            return;
        }

        File file = new File(path);
        // Add extension if not provided
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getAbsolutePath() + ".csv");
        }

        try {
            gradeService.exportToCSV(file);
            System.out.println("[Success] Grades exported successfully to: " + file.getAbsolutePath());
        } catch (IOException e) {
            System.out.println("[Error] Export failed: " + e.getMessage());
        }
    }

    private static void handleClearAll() {
        System.out.println("\n--- CLEAR ALL RECORDS ---");
        System.out.print("Are you sure you want to delete all student records? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        if (confirm.equals("yes") || confirm.equals("y")) {
            gradeService.clearAll();
            System.out.println("[Success] All student records have been cleared.");
        } else {
            System.out.println("Operation cancelled.");
        }
    }
}
