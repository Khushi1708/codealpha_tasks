package com.grademanager.service;

import com.grademanager.model.Student;

import java.io.*;
import java.util.*;

/**
 * Handles operations and statistical analysis on student grades.
 */
public class GradeService {
    private final List<Student> students;

    public GradeService() {
        this.students = new ArrayList<>();
    }

    public synchronized void addStudent(Student student) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(student.getId())) {
                throw new IllegalArgumentException("Student with ID '" + student.getId() + "' already exists.");
            }
        }
        students.add(student);
    }

    public synchronized boolean removeStudent(String id) {
        return students.removeIf(s -> s.getId().equalsIgnoreCase(id));
    }

    public synchronized void updateStudent(String id, String name, double score) {
        for (Student s : students) {
            if (s.getId().equalsIgnoreCase(id)) {
                s.setName(name);
                s.setScore(score);
                return;
            }
        }
        throw new NoSuchElementException("Student with ID '" + id + "' not found.");
    }

    public synchronized List<Student> getStudents() {
        return new ArrayList<>(students);
    }

    public synchronized int getStudentCount() {
        return students.size();
    }

    public synchronized double calculateAverage() {
        if (students.isEmpty()) {
            return 0.0;
        }
        double sum = 0;
        for (Student s : students) {
            sum += s.getScore();
        }
        return sum / students.size();
    }

    public synchronized Student getHighestScoreStudent() {
        if (students.isEmpty()) {
            return null;
        }
        Student highest = students.get(0);
        for (Student s : students) {
            if (s.getScore() > highest.getScore()) {
                highest = s;
            }
        }
        return highest;
    }

    public synchronized Student getLowestScoreStudent() {
        if (students.isEmpty()) {
            return null;
        }
        Student lowest = students.get(0);
        for (Student s : students) {
            if (s.getScore() < lowest.getScore()) {
                lowest = s;
            }
        }
        return lowest;
    }

    /**
     * Categorizes grades into letter grade brackets:
     * A: [90, 100]
     * B: [80, 90)
     * C: [70, 80)
     * D: [60, 70)
     * F: [0, 60)
     */
    public synchronized Map<String, Integer> getGradeDistribution() {
        Map<String, Integer> dist = new LinkedHashMap<>();
        dist.put("A (90-100)", 0);
        dist.put("B (80-89)", 0);
        dist.put("C (70-79)", 0);
        dist.put("D (60-69)", 0);
        dist.put("F (<60)", 0);

        for (Student s : students) {
            double score = s.getScore();
            if (score >= 90.0) {
                dist.put("A (90-100)", dist.get("A (90-100)") + 1);
            } else if (score >= 80.0) {
                dist.put("B (80-89)", dist.get("B (80-89)") + 1);
            } else if (score >= 70.0) {
                dist.put("C (70-79)", dist.get("C (70-79)") + 1);
            } else if (score >= 60.0) {
                dist.put("D (60-69)", dist.get("D (60-69)") + 1);
            } else {
                dist.put("F (<60)", dist.get("F (<60)") + 1);
            }
        }
        return dist;
    }

    public synchronized void clearAll() {
        students.clear();
    }

    public synchronized void loadMockData() {
        clearAll();
        students.add(new Student("S101", "Emma Watson", 92.5));
        students.add(new Student("S102", "Liam Neeson", 84.0));
        students.add(new Student("S103", "Olivia Wilde", 78.5));
        students.add(new Student("S104", "Noah Centineo", 63.0));
        students.add(new Student("S105", "Sophia Loren", 95.0));
        students.add(new Student("S106", "Jackson Pollock", 45.5));
        students.add(new Student("S107", "Mia Hamm", 88.0));
        students.add(new Student("S108", "Lucas Hedges", 72.0));
    }

    public synchronized void exportToCSV(File file) throws IOException {
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file)))) {
            writer.println("Student ID,Name,Grade");
            for (Student s : students) {
                // Simple escaping for names with commas
                String name = s.getName();
                if (name.contains(",")) {
                    name = "\"" + name.replace("\"", "\"\"") + "\"";
                }
                writer.printf("%s,%s,%.2f%n", s.getId(), name, s.getScore());
            }
        }
    }

    public synchronized void importFromCSV(File file) throws IOException {
        List<Student> imported = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String header = reader.readLine(); // skip header
            String line;
            int lineNum = 1;
            while ((line = reader.readLine()) != null) {
                lineNum++;
                if (line.trim().isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length < 3) {
                    throw new IOException("Malformed CSV row at line " + lineNum + ": expected at least 3 columns.");
                }
                String id = parts[0].trim();
                String name = parts[1].trim();
                double score;
                try {
                    score = Double.parseDouble(parts[2].trim());
                } catch (NumberFormatException e) {
                    throw new IOException("Invalid score value at line " + lineNum + ": " + parts[2]);
                }
                imported.add(new Student(id, name, score));
            }
        }
        // If parsing succeeds, update our list (checking for duplicates within the imported list first)
        Set<String> ids = new HashSet<>();
        for (Student s : imported) {
            if (!ids.add(s.getId().toLowerCase())) {
                throw new IOException("CSV contains duplicate student ID: " + s.getId());
            }
        }
        clearAll();
        for (Student s : imported) {
            addStudent(s);
        }
    }

    private String[] parseCsvLine(String line) {
        List<String> tokens = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    sb.append('"'); // escaped quote
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                tokens.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        tokens.add(sb.toString());
        return tokens.toArray(new String[0]);
    }
}
